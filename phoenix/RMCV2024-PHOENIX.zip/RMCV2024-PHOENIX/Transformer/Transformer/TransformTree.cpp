#include "Transformer/TransformTree.hpp"

namespace PHOENIX
{
void TransformTree::addTransform(const std::string &from, const std::string &to,
                                 const Eigen::Vector3d &translation,
                                 const Eigen::Quaterniond &rotation)
{
    this->addTransform(from, to, Transform(translation, rotation));
}

void TransformTree::addTransform(const std::string &from, const std::string &to,
                                 const Transform &transform)
{
    // 添加正向变换
    if (buffer.find(from) == buffer.end())
        buffer.insert(
            std::make_pair(from, std::unordered_map<std::string, Transform>()));
    if (buffer[from].find(to) == buffer[from].end())
        buffer[from].insert(std::make_pair(to, transform));
    else
        buffer[from][to] = transform;
    if (flag.empty() || flag.find(from) == flag.end())
        flag.insert(std::make_pair(from, false));
    // 添加逆向变换
    if (buffer.find(to) == buffer.end())
        buffer.insert(
            std::make_pair(to, std::unordered_map<std::string, Transform>()));
    if (buffer[to].find(from) == buffer[to].end())
        buffer[to].insert(std::make_pair(from, -transform));
    else
        buffer[to][from] = -transform;
    if (flag.empty() || flag.find(to) == flag.end())
        flag.insert(std::make_pair(to, false));
}

Transform TransformTree::getTransform(const std::string &from,
                                      const std::string &to)
{
    if (buffer.find(from) == buffer.end() ||
        flag[from] == true) // 递归边界：未找到变换前的坐标系或已经访问过
        return TRANSFORM_NOT_FOUND;
    if (from == to) // 递归边界：自身变换
        return TRANSFORM_TO_SELF;
    if (buffer[from].find(to) != buffer[from].end()) // 递归边界：找到了直接变换
        return buffer[from][to];

    // 未找到直接变换，递归查找
    Transform res = TRANSFORM_NOT_FOUND;
    flag[from] = true; // 防止环路
    for (auto &i : buffer[from]) {
        res = this->getTransform(i.first, to); // DFS
        if (res != TRANSFORM_NOT_FOUND) {
            res = i.second + res;
            break;
        }
    }
    flag[from] = false;
    return res;
}

} // namespace PHOENIX