#include "Transformer/Transformer.hpp"

#include "Utils/Protocol/IPC.hpp"
#include "Utils/function/Timestamp.hpp"

namespace PHOENIX
{
TransformPublisher::TransformPublisher()
    : transmitter("PHOENIX_transform", []() {
        Config::Config cfg;
        cfg.set("BackEnd", "SHM_SYSV");
        cfg.set("BufferSize",
                std::to_string(sizeof(Utils::IPCProtocol::TransformMsg)));
        return cfg;
    }())
{
}

TransformPublisher::~TransformPublisher()
{
    transmitter.~Transmitter();
}

void TransformPublisher::publish(const std::string &from, const std::string &to,
                                 const Transform &transform)
{
    static Utils::IPCProtocol::TransformMsg *msg =
        new Utils::IPCProtocol::TransformMsg;
    msg->timestamp = Utils::Timestamp::getTimestamp();
    msg->translation[0] = transform.translation.x();
    msg->translation[1] = transform.translation.y();
    msg->translation[2] = transform.translation.z();
    msg->rotation[0] = transform.rotation.w();
    msg->rotation[1] = transform.rotation.x();
    msg->rotation[2] = transform.rotation.y();
    msg->rotation[3] = transform.rotation.z();
    strcpy(msg->from, from.c_str());
    strcpy(msg->to, to.c_str());
    transmitter.send((char *)msg, sizeof(Utils::IPCProtocol::TransformMsg));
}

TransformSubscriber::TransformSubscriber(int duration)
    : TransformBuffer(duration)
    , receiver("PHOENIX_transform", []() {
        Config::Config cfg;
        cfg.set("BackEnd", "SHM_SYSV");
        cfg.set("BufferSize",
                std::to_string(sizeof(Utils::IPCProtocol::TransformMsg)));
        return cfg;
    }())
{
    receiverThread = std::thread(&TransformSubscriber::receive, this);
}

void TransformSubscriber::receive()
{
    Utils::IPCProtocol::TransformMsg *msg =
        new Utils::IPCProtocol::TransformMsg;
    while (true) {
        this->receiver.receive((char *)msg,
                               sizeof(Utils::IPCProtocol::TransformMsg));

        Transform tf =
            Transform(Eigen::Vector3d(msg->translation[0], msg->translation[1],
                                      msg->translation[2]),
                      Eigen::Quaterniond(msg->rotation[0], msg->rotation[1],
                                         msg->rotation[2], msg->rotation[3]));
        if (tf == TRANSFORM_NOT_FOUND) {
            continue;
        }
        this->addTransform(msg->timestamp, std::string(msg->from),
                           std::string(msg->to), tf);
    }
}

TransformSubscriber::~TransformSubscriber()
{
    receiver.~Receiver();
    receiverThread.~thread();
}
} // namespace PHOENIX