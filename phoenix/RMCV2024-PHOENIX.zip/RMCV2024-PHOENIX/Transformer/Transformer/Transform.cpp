#include "Transformer/Transform.hpp"

namespace PHOENIX
{
Transform::Transform(const Eigen::Vector3d &translation,
                     const Eigen::Quaterniond &rotation)
    : translation(translation)
    , rotation(rotation)
{
}

Transform Transform::operator-(const Transform &other) const
{
    return Transform(this->translation - other.translation,
                     this->rotation * other.rotation.conjugate());
}

Transform Transform::operator-() const
{
    return Transform(-this->translation, this->rotation.conjugate());
}

Transform Transform::operator+(const Transform &other) const
{
    return Transform(this->translation + other.translation,
                     this->rotation * other.rotation);
}

Transform Transform::operator=(const Transform &other)
{
    this->translation = other.translation;
    this->rotation = other.rotation;
    return *this;
}

bool Transform::operator==(const Transform &other) const
{
    return this->translation == other.translation &&
           this->rotation.w() == other.rotation.w() &&
           this->rotation.x() == other.rotation.x() &&
           this->rotation.y() == other.rotation.y() &&
           this->rotation.z() == other.rotation.z();
}
}