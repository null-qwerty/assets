#include "Transformer/TransformBuffer.hpp"

#include "Utils/function/Timestamp.hpp"
#include <string>
#include <iostream>

const long Unit = 1E3;
namespace PHOENIX
{
TransformBuffer::TransformBuffer(long buffer_size)
    : buffer_size(buffer_size)
{
}

TransformBuffer::~TransformBuffer()
{
}

void TransformBuffer::addTransform(long timestamp, const std::string &from,
                                   const std::string &to,
                                   const Eigen::Vector3d &translation,
                                   const Eigen::Quaterniond &rotation)
{
    this->addTransform(timestamp, from, to, Transform(translation, rotation));
}

void TransformBuffer::addTransform(long timestamp, const std::string &from,
                                   const std::string &to,
                                   const Transform &transform)
{
    timestamp = timestamp / Unit * Unit;
    std::unique_lock<std::shared_mutex> lock(this->mutex);
    if (this->buffer.empty() ||
        this->buffer.find(timestamp) == this->buffer.end())
        this->buffer[timestamp] = TransformTree();
    this->buffer[timestamp].addTransform(from, to, transform);
}

Transform TransformBuffer::getTransform(const long timestamp,
                                        const std::string &from,
                                        const std::string &to)
{
    if (this->buffer.empty()) {
        return TRANSFORM_BUFFER_EMPTY;
    }
    this->DeleteExpiredTransform();
    long t = timestamp / Unit * Unit;
    if (this->buffer.find(t) != this->buffer.end())
        return this->buffer[t].getTransform(from, to);
    // 没有直接的转换关系，进行插补
    Transform before = TRANSFORM_NOT_FOUND;
    Transform after = TRANSFORM_NOT_FOUND;
    long temp = buffer.begin()->first;

    for (auto i = this->buffer.begin(); i != this->buffer.end(); i++) {
        if (i->first > t) {
            after = i->second.getTransform(from, to);

            if (before ==
                TRANSFORM_NOT_FOUND) // 未找到时间戳之前的变换，无法插补
                break;
            else if (after ==
                     TRANSFORM_NOT_FOUND) // 未找到当前时间戳的变换，继续查找
                continue;
            else {
                double ratio = (t - temp) / (i->first - temp); // 线性插补
                Transform res = before;
                res.translation +=
                    (after.translation - before.translation) * ratio;
                res.rotation =
                    res.rotation.slerp(ratio, after.rotation); // 圆弧插补
                return res;
            }
        } else if (i->second.getTransform(from, to) !=
                   TRANSFORM_NOT_FOUND) { // 记录时间戳之前的最近的变换
            before = i->second.getTransform(from, to);
            temp = i->first;
        }
    }
    return TRANSFORM_NOT_FOUND;
}

void TransformBuffer::DeleteExpiredTransform()
{
    // 清理过期数据
    std::shared_lock<std::shared_mutex> lock(this->mutex);
    for (auto i = this->buffer.begin(); this->buffer.size() > this->buffer_size;
         i = this->buffer.begin())
        if (i->first < Utils::Timestamp::getTimestamp() - this->buffer_size) {
            this->buffer.erase(i++);
        }
}
} // namespace PHOENIX