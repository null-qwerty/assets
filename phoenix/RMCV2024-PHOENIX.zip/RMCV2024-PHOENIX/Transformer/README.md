# Transformer 库

## Transform

一个坐标转换结构体，存储平移和旋转信息。

```cpp
struct Transform {
    Eigen::Vector3d translation;
    Eigen::Quaterniond rotation;

    Transform() = default;
    /**
     * @brief 构造一个坐标系变换
     * @param translation 平移向量
     * @param rotation 旋转四元数
    */
    Transform(const Eigen::Vector3d &translation,
              const Eigen::Quaterniond &rotation);
    ~Transform() = default;

    Transform operator-(const Transform &other) const;
    Transform operator-() const;
    Transform operator+(const Transform &other) const;
    Transform operator=(const Transform &other);
    bool operator==(const Transform &other) const;
    bool operator!=(const Transform &other) const
    {
        return !(*this == other);
    }
};
```

## TransformTree

使用 `std::unordered_map` 实现的 tf 树，提供坐标系转换功能。

```cpp
class TransformTree {
private:
    TransformTree_ buffer;
    std::unordered_map<std::string, bool> flag = {};

public:
    TransformTree() = default;
    ~TransformTree() = default;

    /**
     * @brief 添加一个坐标系变换
     * @param from 变换前的坐标系
     * @param to 变换后的坐标系
     * @param translation 平移向量
     * @param rotation 旋转四元数
    */
    void addTransform(const std::string &from, const std::string &to,
                      const Eigen::Vector3d &translation,
                      const Eigen::Quaterniond &rotation);

    /**
     * @brief 添加一个坐标系变换
     * @param from 变换前的坐标系
     * @param to 变换后的坐标系
     * @param transform 变换后的坐标系相对于变换前的坐标系的转换关系
    */
    void addTransform(const std::string &from, const std::string &to,
                      const Transform &transform);

    /**
     * @brief 获取一个坐标系变换
     * @param from 变换前的坐标系
     * @param to 变换后的坐标系
     * @return 变换后的坐标系相对于变换前的坐标系的转换关系
    */
    Transform getTransform(const std::string &from, const std::string &to);
};
```
其中，`TransformTree_` 定义如下：

```cpp
typedef std::unordered_map<std::string,
                           std::unordered_map<std::string, Transform>>
    TransformTree_;
```

## TransformBuffer

带有时间戳的坐标系转换缓存。

```cpp
class TransformBuffer {
private:
    std::map<long, TransformTree> buffer;

    void DeleteExpiredTransform();

protected:
    mutable std::shared_mutex mutex;
    long duration;

    void addTransform(long timestamp, const std::string &from,
                      const std::string &to, const Eigen::Vector3d &translation,
                      const Eigen::Quaterniond &rotation);

    void addTransform(long timestamp, const std::string &from,
                      const std::string &to, const Transform &transform);

public:
    TransformBuffer(long duration = 1);
    ~TransformBuffer();

    /**
     * @brief 获取一个坐标系变换
     * @param timestamp 时间戳
     * @param from 变换前的坐标系
     * @param to 变换后的坐标系
     * @return 变换后的坐标系相对于变换前的坐标系的转换关系
    */
    Transform getTransform(const long timestamp, const std::string &from,
                           const std::string &to);
};
```
## Transformer

提供发送坐标系变换的`TransformPublisher`和接收坐标系变换的`TransformSubscriber`。

```cpp
class TransformPublisher {
private:
    Config::Config cfg;

    Transceiver::Transmitter transmitter;

public:
    TransformPublisher();
    ~TransformPublisher();
    void publish(const std::string &from, const std::string &to,
                 const Transform &transform);
};
```

```cpp
class TransformSubscriber : public TransformBuffer {
private:
    Config::Config cfg;
    Transceiver::Receiver receiver;
    std::thread receiverThread;

    void receive();
public:
    TransformSubscriber(int duration = 1);
    ~TransformSubscriber();
};
```