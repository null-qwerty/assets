# Serial库

将boost中串口通信做了简易封装

## Serial类

### 构造

```cpp
  /*
   * @brief Serial构造函数, 对象创建后会自动打开串口
   * @param serial_name 串口名
   * @param baud_rate 波特率
   * @param character_size 数据位 默认8
   * @param flow_control 流量控制 默认无
   * @param parity 校验位 默认无
   * @param stop_bits 停止位 默认1
   */
  Serial(std::string serial_name, unsigned int baud_rate,
         unsigned int character_size = 8,
         serial_port::flow_control flow_control =
             serial_port::flow_control(serial_port::flow_control::none),
         serial_port::parity parity =
             serial_port::parity(serial_port::parity::none),
         serial_port::stop_bits stop_bits =
             serial_port::stop_bits(serial_port::stop_bits::one));
```
构造后自动开启串口

### 接收、发送

```cpp
  /*
   * @brief 串口发送函数
   * @tparam T 发送数据结构
   * @param data 发送数据指针
   * @param size 发送数据大小（字节数）
   * @return 发送成功返回true，否则返回false
   */
  template <typename T> bool write(T *data, size_t size);
  /*
   * @brief 串口接收函数
   * @tparam T 接收数据结构
   * @param data 接收数据指针
   * @param size 接收数据大小（字节数）
   * @return 接收成功返回true，否则返回false
   */
  template <typename T> bool receive(T *data, size_t size);

```