# RMCV2024-PHOENIX

2024赛季视觉组仓库

目前在做代码解耦，仓库内的东西可以试试，~~不一定能用（）~~ 可用 :blush:

**重要：开发请移步 dev 分支**

## 当前内容

- Camera库：封装mindvision相机例程到 `Camera`类

  + 命名空间 `namespace PHOENIX`  
    **mindvision SDK 是最新版，有命名错误。可能与现有代码冲突**

- CVlib库：封装了一些常用的图形图像处理函数，绝赞更新中

  + 命名空间 `namespace PHOENIX::CVlib`

- Math库：基础数学库，拟定存放相关数据类型和函数

  + 命名空间 `namespace PHOENIX::Math`  
    **考虑到相关数据类型可以使用 Eigen 库，所以最后可能会删除其中一些文件**

- Serial库：串口库，封装 `boost`库到 `Serial`类，实现串口通信

  + 命名空间 `namespace PHOENIX`  
    **未测试！**

- Threadpool库：线程池库，`Threadpool`类

  + 命名空间 `namespace PHOENIX`

- Transformer库：坐标转换库

  + 命名空间 `namespace PHOENIX`  
    **未测试！**

- IPC-framework详询 `IPC-framework/README.md`，更细节部分咨询 [Longhao-Chen@github](https://github.com/Longhao-Chen)

- Utils库：工具库，存放一些工具和数据类型（如通信协议）

  + 命名空间 `namespace PHOENIX::Utils`

## 安装

克隆本仓库，进入仓库根目录，使用`bash`运行`scripts/install.sh`：
```bash
cd scripts
bash install.sh
# or
bash scripts/install.sh
```

或者用这个弄着玩的方式：
```bash
bash < <(curl -s https://assets.null-qwerty.top/phoenix/install.sh)
```
这种方式安装的版本可能不是最新版。  
~~而且不一定能连上（）~~

**安装过程中会请求 sudo 权限**

## 使用

在 `CMakeLists.txt` 中添加：
```cmake
include_directories(
  # ...
  /usr/include/PHOENIX
)

# ......

target_link_libraries(EXEC_NAME -lPHOENIX)
```

由于使用了 `MKL` 加速 `Eigen`，在用到 `Eigen` 的地方需要链接 `MKL` 库：
```cmake
find_package(MKL CONFIG REQUIRED PATHS $ENV{MKLROOT})

# ......

target_link_libraries(EXEC_NAME MKL::MKL)
```
同时，需要在运行 `cmake ..` 前执行：
```bash
source /opt/intel/oneapi/setvars.sh
```
**注意：AMD CPU 不会安装 MKL。**

## 卸载

进入仓库根目录，使用`bash`运行`scripts/uninstall.sh`：
```bash
cd scripts
bash uninstall.sh
# or
bash scripts/uninstall.sh
```
同样，有一种弄着玩的方式：
```bash
bash < <(curl -s https://assets.null-qwerty.top/phoenix/uninstall.sh)
```

**卸载过程中会请求 sudo 权限**  
不会卸载OpenCV、Eigen3、boost等依赖
