#include "Utils/function/Timestamp.hpp"

namespace PHOENIX::Utils::Timestamp
{
time_t getTimestamp()
{
    return std::chrono::duration_cast<std::chrono::microseconds>(
               std::chrono::system_clock::now().time_since_epoch())
        .count();
}
}