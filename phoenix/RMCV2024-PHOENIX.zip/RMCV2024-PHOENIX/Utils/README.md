# Utils库

## enum枚举类

### bullet

子弹类型枚举类

```cpp
enum Bullet { Small, Large, Light };
```

### color

队伍颜色枚举类

```cpp
enum COLOR { RED, BLUE };
```

## item

一些常用的数据类型

### Armor

装甲板数据类型

```cpp
struct Armor
{
  Armor() = default;
  Armor(const Light & l1, const Light & l2)
  {
    if (l1.center.x < l2.center.x) {
      left_light = l1, right_light = l2;
    } else {
      left_light = l2, right_light = l1;
    }
    center = (left_light.center + right_light.center) / 2;
  }

  // Light pairs part
  Light left_light, right_light;
  cv::Point2f center;
  ArmorType type;

  // Number part
  cv::Mat number_img;
  std::string number;
  float confidence;
  std::string classfication_result;
  float distance_to_image_center;
  PHOENIX::Math::Pose pose;
};
```

### Light

灯条数据类型

```cpp
struct Light : public cv::RotatedRect {
  Light() = default;
  explicit Light(cv::RotatedRect box) : cv::RotatedRect(box) {
    cv::Point2f p[4];
    box.points(p);
    std::sort(p, p + 4, [](const cv::Point2f &a, const cv::Point2f &b) {
      return a.y < b.y;
    });
    top = (p[0] + p[1]) / 2;
    bottom = (p[2] + p[3]) / 2;

    length = cv::norm(top - bottom);
    width = cv::norm(p[0] - p[1]);

    tilt_angle =
        std::atan2(std::abs(top.x - bottom.x), std::abs(top.y - bottom.y));
    tilt_angle = tilt_angle / CV_PI * 180;
  }

  int color;
  cv::Point2f top, bottom;
  double length;
  double width;
  float tilt_angle;
};
```
### ObjectPoints

识别目标的尺寸信息，供solvePnP使用


```cpp
static constexpr float SMALL_ARMOR_WIDTH = 135;
static constexpr float SMALL_ARMOR_HEIGHT = 55;
static constexpr float LARGE_ARMOR_WIDTH = 225;
static constexpr float LARGE_ARMOR_HEIGHT = 55;
static constexpr float EXCHANGE_STATION_SIZE = 288;
// Unit: m
static constexpr float SMALL_ARMOR_WIDTH_HALF = SMALL_ARMOR_WIDTH / 2.0 / 1000;
static constexpr float SMALL_ARMOR_HEIGHT_HALF =
    SMALL_ARMOR_HEIGHT / 2.0 / 1000;
static constexpr float LARGE_ARMOR_WIDTH_HALF = LARGE_ARMOR_WIDTH / 2.0 / 1000;
static constexpr float LARGE_ARMOR_HEIGHT_HALF =
    LARGE_ARMOR_HEIGHT / 2.0 / 1000;
static constexpr float EXCHANGE_STATION_SIZE_HALF =
    EXCHANGE_STATION_SIZE / 2.0 / 1000;

// 左下角为原点，顺时针
const std::vector<cv::Point3f> small_armor(
    { cv::Point3f(0, SMALL_ARMOR_WIDTH_HALF, -SMALL_ARMOR_HEIGHT_HALF),
      cv::Point3f(0, SMALL_ARMOR_WIDTH_HALF, SMALL_ARMOR_HEIGHT_HALF),
      cv::Point3f(0, -SMALL_ARMOR_WIDTH_HALF, SMALL_ARMOR_HEIGHT_HALF),
      cv::Point3f(0, -SMALL_ARMOR_WIDTH_HALF, -SMALL_ARMOR_HEIGHT_HALF) });

// 左下角为原点，顺时针
const std::vector<cv::Point3f> large_armor(
    { cv::Point3f(0, LARGE_ARMOR_WIDTH_HALF, -LARGE_ARMOR_HEIGHT_HALF),
      cv::Point3f(0, LARGE_ARMOR_WIDTH_HALF, LARGE_ARMOR_HEIGHT_HALF),
      cv::Point3f(0, -LARGE_ARMOR_WIDTH_HALF, LARGE_ARMOR_HEIGHT_HALF),
      cv::Point3f(0, -LARGE_ARMOR_WIDTH_HALF, -LARGE_ARMOR_HEIGHT_HALF) });

// 右上角为原点，逆时针
const std::vector<cv::Point3f> exchange_station(
    { cv::Point3f(0, -EXCHANGE_STATION_SIZE_HALF, EXCHANGE_STATION_SIZE_HALF),
      cv::Point3f(0, EXCHANGE_STATION_SIZE_HALF, EXCHANGE_STATION_SIZE_HALF),
      cv::Point3f(0, EXCHANGE_STATION_SIZE_HALF, -EXCHANGE_STATION_SIZE_HALF),
      cv::Point3f(0, -EXCHANGE_STATION_SIZE_HALF,
                  -EXCHANGE_STATION_SIZE_HALF) });
```

## protocol

通信协议

### IPC

IPC通信协议，意义不大，已废弃，后续考虑移除

```cpp
/*
 * @param type_name: 自定义消息类型名称,
 * 最后创建的结构名称会在type_name后加上Msg
 * @param type_size: 自定义消息类型大小
 */
#define CostumType(type_name, type_size) \
    typedef struct {                     \
        time_t timestamp;                \
        uint8_t data[type_size];         \
    } type_name##Msg;

/*
 * @tparam dataTp: 数据的结构
 */
template <typename dataTp> struct TemplateMsg {
    time_t timestamp;
    dataTp data;
};

typedef struct Int32ArrayProtocol_s {
    time_t timestamp;
    std::vector<int> data;
} IntArrayMsg;

typedef struct Float32ArrayProtocol_s {
    time_t timestamp;
    std::vector<float> data;
} Float32ArrayMsg;

typedef struct ImageProtocol_s {
    time_t timestamp;
    cv::Mat *data;
} ImageMsg;
```

### Serial

串口通信协议，感觉意义也不大，可能也会废弃

```cpp
/*
 * @param car_name: 兵种名称
 * @param type_size: 自定义消息类型大小，除去头尾
 */
#define CostumType(car_name, buffer_size)  \
    typedef union {                        \
        struct {                           \
            uint8_t start = 's';           \
            uint8_t buffer[type_size - 2]; \
            uint8_t end = 'e';             \
        } data;                            \
        uint8_t *buffer;                   \
    } car_name;

/*
 * @tparam dataTp: 数据包除去头尾的数据结构
 */
template <typename dataTp> union TemplateProtocol {
    struct {
        uint8_t start = 's';
        dataTp data;
        uint8_t end = 'e';
    };
    uint8_t *buffer;
};

typedef union SentinalProtocol { // 哨兵上下位机通信协议
    struct {
        uint8_t start = 's'; //  0 帧头，取 's’
        uint8_t type; //  1 消息类型
        /* type 取值：
                          *       上位机发下位机
                          *      0xA0     底盘控制
                          *      0xA1     云台控制
                          *      0xA2     射击控制
                          *       下位机发上位机
                          *      0xB0     底盘反馈
                          *      0xB1     位移信息
                          *      0xB2     云台陀螺仪信息
                          *      0xB3     比赛信息
                          *      0xB4     位置信息
                          */
        uint8_t buffer[29]; //  2 ~ 30 数据
        uint8_t end = 'e'; // 31 帧尾，取 'e'
    } data;
    uint8_t *buffer;
} Sentinal;

typedef union InfantrySendProtocol { // 步兵上下位机通信发送协议
    struct {
        char start = 's'; // 0         开始位(s)
        char is_find; // 1         是否找到目标
        char can_shoot; // 2         是否可以射击
        float yaw; // 3 ~ 6     yaw 偏移量
        float pitch; // 7 ~ 10    pitch 偏移量
        float origin_yaw; // 11 ~ 14   接收到的 yaw
        float origin_pitch; // 15 ~ 18   接收到的 pitch
        float distance; // 19 ~ 22   目标距离
        char mode; // 23        模式 装甲板：a  符：r
        int id = -1; // 24 ~ 27     ？
        char unused[3] = {}; // 28 ~ 30     预留位
        char end = 'e'; // 31        结束位
    } data;
    uint8_t *buffer;
} InfantrySend;

typedef union InfantryRecvProtocol { // 步兵上下位机通信接收协议
    struct {
        char start = 's'; // 0       开始位
        char color; // 1       颜色
        char mode; // 2       模式 装甲板：a  符：r
        float speed = 20; // 3 ~ 6   速度
        float euler[3] = {}; // 7 ~ 24    欧拉角 (0,1,2) = (yaw,roll,pitch)
        char shoot_bool = 0; // 25
        char rune_flag = 0; // 26      0为不可激活，1为小符，2为大符
        char unused[10] = {}; // 27 ~ 30
        char end = 'e'; // 31
    } data;
    uint8_t *buffer;
} InfantryRecv;

typedef union HeroSendProtocol { // 英雄上下位机通信发送协议
    struct {
        char start = 's'; // 0         开始位(s)
        char is_find; // 1         是否找到目标
        char can_shoot; // 2         是否可以射击
        float yaw; // 3 ~ 6     yaw 偏移量
        float pitch; // 7 ~ 10    pitch 偏移量
        float origin_yaw; // 11 ~ 14   接收到的 yaw
        float origin_pitch; // 15 ~ 18   接收到的 pitch
        float distance; // 19 ~ 22   目标距离
        char mode; // 23        模式 装甲板：a  符：r
        int id = -1; // 24 ~ 27     ？
        char unused[3] = {}; // 28 ~ 30     预留位
        char end = 'e'; // 31        结束位
    } data;
    uint8_t *buffer;
} HeroSend;

typedef union HeroRecvProtocol { // 英雄上下位机通信接收协议
    struct {
        char start = 's'; // 0       开始位
        char color; // 1       颜色
        char mode; // 2       模式 装甲板：a  符：r
        float speed = 20; // 3 ~ 6   速度
        float euler[3] = {}; // 7 ~ 24    欧拉角 (0,1,2) = (yaw,roll,pitch)
        char shoot_bool = 0; // 25
        char rune_flag = 0; // 26      0为不可激活，1为小符，2为大符
        char unused[10] = {}; // 27 ~ 30
        char end = 'e'; // 31
    } data;
    uint8_t *buffer;
} HeroRecv;

typedef union AirplaneProtocol { // 飞机上下位机通信协议
    struct {
        uint8_t start;
        uint8_t buffer[30];
        uint8_t end;
    } data;
    uint8_t *buffer;
} Airplane;

typedef union EngineerProtocol { // 工程上下位机通信协议
    struct {
        uint8_t start;
        uint8_t buffer[30];
        uint8_t end;
    } data;
    uint8_t *buffer;
} Engineer;
```