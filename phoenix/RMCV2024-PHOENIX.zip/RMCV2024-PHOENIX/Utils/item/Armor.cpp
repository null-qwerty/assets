#include "Utils/item/Armor.hpp"

namespace PHOENIX::Utils
{
Armor::Armor(const Light &l1, const Light &l2)
{
    if (l1.center.x < l2.center.x) {
        left_light = l1, right_light = l2;
    } else {
        left_light = l2, right_light = l1;
    }
    center = (left_light.center + right_light.center) / 2;
}
} // namespace PHOENIX::Utils