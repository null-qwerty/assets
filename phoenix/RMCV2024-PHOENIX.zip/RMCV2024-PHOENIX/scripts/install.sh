DIRNAME=$0
if [ "${DIRNAME:0:1}" = "/" ];then
    SHDIR=`dirname $DIRNAME`
else
    SHDIR="`pwd`"/"`dirname $DIRNAME`"
fi

cd $SHDIR

bash ./check_submodules.sh
sleep 1
bash ./requirements_installer.sh
sleep 1
bash ./mindvision_installer.sh
sleep 1
bash ./IPC-framework_installer.sh
sleep 1
bash ./PHOENIX_installer.sh
echo "请重启计算机"