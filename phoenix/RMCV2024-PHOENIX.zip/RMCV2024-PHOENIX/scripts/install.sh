#!/bin/bash
DIRNAME=$0
if [ "${DIRNAME:0:1}" = "/" ];then
    SHDIR=`dirname $DIRNAME`
else
    SHDIR="`pwd`"/"`dirname $DIRNAME`"
fi

cd $SHDIR

DISTROS=$(whiptail --title "RMCV2024-PHOENIX installer" --checklist \
"选择要安装的内容\n \
 [↑/←] 上移   [↓/→] 下移    [SpaceBar] 选择    [ESC] 取消" \
 15 70 5 \
"Submodule" "检查子模块是否初始化，若没有则进行初始化" OFF \
"Requirements" "将安装 OpenCV、Eigen 等" OFF \
"Mindvision" "安装迈德威视相机 SDK，若安装本库请勾选" OFF \
"IPC-framework" "安装 IPC-framework" OFF \
"PHOENIX" "安装本仓库" OFF 3>&1 1>&2 2>&3
)

exitstatus=$?
if [ $exitstatus != 0 ]; then
    echo -e "\e[31m[install.sh] 取消安装\e[0m"
    exit 1
fi

if [[ $DISTROS == *"Submodule"* ]]; then
    bash ./check_submodules.sh
    sleep 1
fi
if [[ $DISTROS == *"Requirements"* ]]; then
    bash ./requirements_installer.sh
    sleep 1
fi
if [[ $DISTROS == *"Mindvision"* ]]; then
    bash ./mindvision_installer.sh
    sleep 1
fi
if [[ $DISTROS == *"IPC-framework"* ]]; then
    bash ./IPC-framework_installer.sh
    sleep 1
fi
if [[ $DISTROS == *"PHOENIX"* ]]; then
    bash ./PHOENIX_installer.sh
    sleep 1
fi

echo -e "\e[32m[install.sh] 安装完成\e[0m"