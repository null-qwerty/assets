echo "[requirements] 安装 OpenCV、Boost、Eigen3 等依赖，基于 apt"
echo "[requirements] 请保证网络连接通畅"

array=("libopencv-dev" "libboost-all-dev" "libeigen3-dev" "libpcl-dev" "unar" "libunwind-dev")
# 如果是 Intel CPU，加载 Intel oneAPI MKL
if [ "$(cat /proc/cpuinfo | grep "vendor_id" | awk '{print $3}' | uniq)" == "GenuineIntel" ]; then
    echo -e "\e[32m[requirements] 检测到 Intel CPU，将安装 Intel oneAPI MKL\e[0m"
    array+=("intel-oneapi-mkl-devel")
    wget https://apt.repos.intel.com/intel-gpg-keys/GPG-PUB-KEY-INTEL-SW-PRODUCTS.PUB
    sudo apt-key add GPG-PUB-KEY-INTEL-SW-PRODUCTS.PUB
    rm GPG-PUB-KEY-INTEL-SW-PRODUCTS.PUB
    echo "deb https://apt.repos.intel.com/oneapi all main" | sudo tee /etc/apt/sources.list.d/oneAPI.list
else
    echo -e "\e[33m[requirements] 非 Intel CPU，排除 MKL\e[0m"
fi
echo "[requirements] 将安装以下包:"
for i in ${array[@]}
do
    echo "- $i"
done
echo -e "\e[31m[requirements] 5 秒后开始安装...\e[0m"
sleep 5

echo "[requirements] 更新源"
sleep 1
sudo apt update
echo "[requirements] 开始安装"
sudo apt install -y ${array[@]}
echo "[requirements] 安装完成"