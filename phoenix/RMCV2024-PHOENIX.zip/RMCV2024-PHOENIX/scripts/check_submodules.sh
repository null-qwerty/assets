DIRNAME=$0
if [ "${DIRNAME:0:1}" = "/" ];then
    SHDIR=`dirname $DIRNAME`
else
    SHDIR="`pwd`"/"`dirname $DIRNAME`"
fi

ROOT=$SHDIR/..
cd $ROOT

echo "[check_submodules] 检查子模块是否初始化..."

if [ ! "$(ls IPC-framework)" ]; then
    git submodule init
    git submodule update
    echo "[check_submodules] 子模块初始化完成"
fi

echo "[check_submodules] 所有子模块均已初始化！"