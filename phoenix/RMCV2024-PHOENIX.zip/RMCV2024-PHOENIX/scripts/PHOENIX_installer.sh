DIRNAME=$0
if [ "${DIRNAME:0:1}" = "/" ];then
    SHDIR=`dirname $DIRNAME`
else
    SHDIR="`pwd`"/"`dirname $DIRNAME`"
fi

ROOT=$SHDIR/..
cd $ROOT

# 安装其他包
echo "[PHOENIX] 准备编译"
sleep 1
if [ -d "build" ]; then
    sudo rm -r build
fi
mkdir build
cd build
# 如果是 Intel CPU，加载 Intel oneAPI 环境
if [ "$(cat /proc/cpuinfo | grep "vendor_id" | awk '{print $3}' | uniq)" == "GenuineIntel" ]; then
    source /opt/intel/oneapi/setvars.sh
fi
cmake ..
make -j
if [ ! -f "libPHOENIX.so" ]; then
    echo "[PHOENIX] 编译失败"
    exit 1
fi
echo "[PHOENIX] 编译完成"
echo "[PHOENIX] 复制动态库"
sudo cp libPHOENIX.so /usr/lib/x86_64-linux-gnu/
echo "[PHOENIX] 复制头文件"
cd $ROOT
if [ -d "/usr/include/PHOENIX" ]; then
    sudo rm -r /usr/include/PHOENIX
fi
sudo cp -r PHOENIX/ /usr/include
echo "[PHOENIX] 安装完成"