DIRNAME=$0
if [ "${DIRNAME:0:1}" = "/" ];then
    SHDIR=`dirname $DIRNAME`
else
    SHDIR="`pwd`"/"`dirname $DIRNAME`"
fi

ROOT=$SHDIR/..
cd $ROOT

# 安装 IPC-framework
echo "[IPC-framework] 准备安装"
sleep 1
cd IPC-framework
sudo make install
if [ ! -f "libipc_framework.so" ]; then
    echo "[IPC-framework] 安装失败"
    exit 1
fi
echo "[IPC-framework] 安装完成"