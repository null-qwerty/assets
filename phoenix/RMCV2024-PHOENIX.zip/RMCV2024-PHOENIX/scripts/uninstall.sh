DIRNAME=$0
if [ "${DIRNAME:0:1}" = "/" ];then
    SHDIR=`dirname $DIRNAME`
else
    SHDIR="`pwd`"/"`dirname $DIRNAME`"
fi

ROOT=$SHDIR/..
cd $ROOT

INCLUDE_PATH=/usr/include

echo "卸载 mindvision SDK..."
sudo rm $INCLUDE_PATH/CameraApi.h $INCLUDE_PATH/CameraDefine.h $INCLUDE_PATH/CameraStatus.h
sudo rm /lib/libMVSDK.so
echo "[mindvision SDK] 卸载完成！"

echo "卸载 IPC-framework..."
cd  $ROOT/IPC-framework
sudo make uninstall
echo "[IPC-framework] 卸载完成！"

echo "卸载 PHOENIX..."
sudo rm -r $INCLUDE_PATH/PHOENIX/
sudo rm /usr/lib/x86_64-linux-gnu/libPHOENIX.so
echo "[PHOENIX] 卸载完成！"