DIRNAME=$0
if [ "${DIRNAME:0:1}" = "/" ];then
    SHDIR=`dirname $DIRNAME`
else
    SHDIR="`pwd`"/"`dirname $DIRNAME`"
fi

ROOT=$SHDIR/..
cd $ROOT

# 安装 mindvision SDK
echo "[mindvision SDK] 准备安装"
sleep 1
cd Camera
if [ ! -d SDK ]; then
    echo "[mindvision SDK] 未找到 SDK，开始下载"
    wget --no-check-certificate http://assets.null-qwerty.top/MindvisionSDK.zip
    unar MindvisionSDK.zip
    chmod -R 777 SDK
    echo "[mindvision SDK] 下载完成，准备安装"
    sleep 1
    rm MindvisionSDK.zip
fi
cd SDK
sudo ./install.sh
echo "[mindvision SDK] 安装完成"