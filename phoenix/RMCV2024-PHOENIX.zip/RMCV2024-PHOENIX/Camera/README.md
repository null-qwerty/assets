# Camera库

## Camera类

### 定义

```c++
// namespace PHOENIX
class Camera {
private:
  unsigned char *g_pRgbBuffer; // 处理后数据缓存区
  int iCameraCounts = 1;
  int iStatus = -1;
  tSdkCameraDevInfo tCameraEnumList;
  int hCamera;
  tSdkCameraCapbility tCapability; // 设备描述信息
  tSdkFrameHead sFrameInfo;
  BYTE *pbyBuffer;
  int iDisplayFrames = 10000;
  IplImage *iplImage = NULL;
  int channel = 3;

public:
  Camera();
  ~Camera();
  void init();
  void getFrame(std::shared_ptr<cv::Mat> &frame);
  void close();
  void releasebuffer();
};
```

### 使用

1. 创建对象

   ```c++
   Camera camera;
   ```
   创建后自动初始化相机并启动

2. 获取图片

   ```c++
   std::shared_ptr<cv::Mat> frame;
   camera.getFrame(frame);
   ```