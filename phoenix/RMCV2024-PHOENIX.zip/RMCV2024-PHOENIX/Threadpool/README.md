# Treadpool库

## Treadpool类

线程池类

### 构造函数

```cpp
/*
   * @brief 线程池构造函数
   * @param threads 线程池中线程的数量
   */
  ThreadPool(size_t);
```

### 添加任务进线程池

```cpp
/*
   * @brief 向线程池中添加任务
   * @tparam F 任务函数类型
   * @param f 任务函数
   * @param args 任务函数的参数
   * @return 任务的返回值
   */
  template <class F, class... Args>
  auto enqueue(F &&f, Args &&...args)
      -> std::future<typename std::result_of<F(Args...)>::type>;
```