# Math库

## Point类

三维点类，用于表示三维空间中的点

### 定义

```cpp
// namespace PHOENIX::Math
class Point {
public:
  Point();
  Point(float x, float y, float z);
  Point(const Point &p);
  ~Point();

  Point &operator=(const Point &p);
  Point operator+(const Point &p) const;
  Point &operator+=(const Point &p);
  Point operator-(const Point &p) const;
  Point &operator-=(const Point &p);
  Point operator*(float s) const;
  Point &operator*=(float s);
  Point operator/(float s) const;
  Point &operator/=(float s);
  bool operator==(const Point &p) const;
  bool operator!=(const Point &p) const;

  float Length() const;
  float LengthSquared() const;
  void Normalize();
  Point Normalized() const;

private:
  float x, y, z;
};

typedef Point Point3d;
typedef std::vector<Point> Points;
```

## Quaternion类

四元数类，用于表示旋转

### 定义

```cpp
// namespace PHOENIX::Math
class Quaternion {
public:
  Quaternion();
  /*
   * @brief 从四个分量构造四元数
   * @param x 四元数的x分量
   * @param y 四元数的y分量
   * @param z 四元数的z分量
   * @param w 四元数的w分量
   */
  Quaternion(float x, float y, float z, float w);
  Quaternion(const Quaternion &q);
  /*
   * @brief 从欧拉角构造四元数
   * @param yaw yaw角, 绕z轴旋转, 单位为弧度
   * @param pitch pitch角, 绕y轴旋转, 单位为弧度
   * @param roll roll角, 绕x轴旋转, 单位为弧度
   */
  Quaternion(float yaw, float pitch, float roll);
  ~Quaternion();

  Quaternion &operator=(const Quaternion &q);
  Quaternion operator*(const Quaternion &q) const;
  Quaternion &operator*=(const Quaternion &q);
  Quaternion operator*(float s) const;
  Quaternion &operator*=(float s);
  Quaternion operator+(const Quaternion &q) const;
  Quaternion &operator+=(const Quaternion &q);
  Quaternion operator-(const Quaternion &q) const;
  Quaternion &operator-=(const Quaternion &q);
  Quaternion operator/(float s) const;
  Quaternion &operator/=(float s);
  bool operator==(const Quaternion &q) const;
  bool operator!=(const Quaternion &q) const;

  /*
   * @brief 四元数长度
   * @return 四元数长度
   */
  float Length() const;
  /*
   * @brief 四元数长度的平方
   * @return 四元数长度的平方
   */
  float LengthSquared() const;
  /*
   * @brief 四元数归一化
   */
  void Normalize();
  /*
   * @brief 四元数归一化后的四元数
   * @return 四元数归一化后的四元数
   */
  Quaternion Normalized() const;
  /*
   * @brief 四元数共轭
   */
  void Conjugate();
  /*
   * @brief 四元数共轭后的四元数
   * @return 四元数共轭后的四元数
   */
  Quaternion Conjugated() const;
  /*
   * @brief 四元数求逆
   */
  void Invert();
  /*
   * @brief 四元数求逆后的四元数
   * @return 四元数求逆后的四元数
   */
  Quaternion Inverted() const;
  /*
   * @brief 四元数转欧拉角
   * @param yaw yaw角, 绕z轴旋转, 单位为弧度
   * @param pitch pitch角, 绕y轴旋转, 单位为弧度
   * @param roll roll角, 绕x轴旋转, 单位为弧度
   */
  void ToEuler(float &yaw, float &pitch, float &roll);

private:
  float x, y, z, w;
};
```

## Lead类

龙格库塔法求解抛物线轨迹，用于求解抬枪补偿

### 定义

```cpp
// namespace PHOENIX::Math
class Lead {
    public:
        Eigen::Vector3d shoot_pw;    //预瞄点的世界坐标
        Eigen::Vector3d d_shoot_pw;  //识别到的点增加抬枪补偿后的世界坐标
        Eigen::Vector3d shoot_pc;
        Eigen::Vector3d shoot_pu;
        Eigen::Vector3d orin_pw;
        Eigen::Vector3d orin_pc;
        Eigen::Vector3d orin_pu;

        /**
             * @brief 构造函数设置现实环境的物理量，也可使用没有参数传入的构造函数，会有默认值设置
             * @param gravity 重力加速度常数
             * @param kofsmall 小弹丸风阻系数
             * @param koflarge 大弹丸风阻系数
             * @param koflight 荧光弹丸风阻系数
             * @param R_K_iter 龙格库塔法最大迭代次数
             * @param stop_error 停止迭代的最小误差(单位m)
            */
        Lead(const double& gravity, const double& kofsmall, const float& koflarge, const double& koflight, const double& R_K_iter, const double& stop_error);
          
        /**
             * @brief 使用默认值
            */
        Lead() ;

        ~Lead(){};

        /**
             * @brief 龙格库塔法求解微分方程，取得抬枪补偿(Ps:modify from TUP)
             * @param xyz 目标相对于云台的世界坐标系
             * @param velocity 子弹发射的速度
             * @param mode 子弹类型，有 Bullet::Small,Bullet::Larget,Bullet::Light
            */
        Eigen::Vector2d DynamicCalcCompensate(Eigen::Vector3d& xyz, const float& velocity, const Utils::Bullet& mode); 

        /**
             *@brief 设置手动补偿量,px,py的物理含义为相机到摩擦轮出射处的偏移量
            */
        void SetHandOffSet(const double& x, const double& y);

    private:
        double gravity;     //重力系数
        double kofsmall;    //小弹丸风阻系数
        double koflarge;    //大弹丸风阻系数
        double koflight;    //荧光弹丸风阻系数
        int max_iter;       //龙格库塔法最大迭代次数
        double velocity;    //弹丸速度
        int R_K_iter;       //龙格库塔法求解落点的迭代次数
        double stop_error;  //停止迭代的最小误差(单位m)
        double k;           //风阻系数
        double px;          //yaw轴补偿
        double py;          //pitch轴补偿
    };
```
## Pose类

姿态类，用于描述一个刚体的姿态

### 定义

```cpp
class Pose {
public:
  Pose() = default;
  /*
   * @brief 从position和euler_angles构造Pose
   * @param position 位移，XYZ
   * @param euler_angles 欧拉角, RPY
   * @note 会从欧拉角构造四元数
   */
  Pose(const Eigen::Vector3f &position, const Eigen::Vector3f &euler_angles)
      : position_(position), euler_angles_(euler_angles) {
    quaternion_ = Eigen::Quaternionf(euler_angles_);
  }
  /*
   * @brief 从position和quaternion构造Pose
   * @param position 位移，XYZ
   * @param euler_angles 四元数
   * @note 会从四元数构造欧拉角
   */
  Pose(const Eigen::Vector3f &position, const Eigen::Quaternionf &quaternion)
      : position_(position), quaternion_(quaternion) {
    euler_angles_ = quaternion_.toRotationMatrix().eulerAngles(0, 1, 2);
  }

  Eigen::Vector3f position_;
  Eigen::Vector3f euler_angles_;
  Eigen::Quaternionf quaternion_;

  /*
   * @brief 获取位移
   * @return Eigen::Vector3f position
   */
  Eigen::Vector3f getPosition() const { return position_; }
  /*
   * @brief 获取欧拉角
   * @return Eigen::Vector3f eular_angles
   */
  Eigen::Vector3f getEulerAngles() const { return euler_angles_; }
  /*
   * @brief 获取四元数
   * @return Eigen::Quaternionf quaternion
   */
  Eigen::Quaternionf getQuaternion() const { return quaternion_; }

  /*
   * @brief 设置位移
   * @param position 位移, XYZ
   */
  void setPosition(const Eigen::Vector3f &position) { position_ = position; }
  /*
   * @brief 设置欧拉角
   * @param eular_angles 欧拉角, RPY
   * @note 会从欧拉角构造四元数
   */
  void setEulerAngles(const Eigen::Vector3f &euler_angles) {
    euler_angles_ = euler_angles;
    quaternion_ = Eigen::Quaternionf(euler_angles_);
  }
  /*
   * @brief 设置四元数
   * @param quaternion 四元数
   * @note 会从四元数构造欧拉角
   */
  void setQuaternion(const Eigen::Quaternionf &quaternion) {
    quaternion_ = quaternion;
    euler_angles_ = quaternion_.toRotationMatrix().eulerAngles(0, 1, 2);
  }
  /*
   * @brief 设置位移
   * @param x x方向
   * @param y y方向
   * @param z z方向
   */
  void setPosition(const double &x, const double &y, const double &z) {
    position_ << x, y, z;
    quaternion_ = Eigen::Quaternionf(euler_angles_);
  }
  /*
   * @brief 设置欧拉角
   * @param roll 翻滚角, 绕x轴
   * @param pitch 俯仰角, 绕y轴
   * @param yaw 航向角, 绕z轴
   * @note 会从欧拉角构造四元数
   */
  void setEulerAngles(const double &roll, const double &pitch,
                      const double &yaw) {
    euler_angles_ << roll, pitch, yaw;
    quaternion_ = Eigen::Quaternionf(euler_angles_);
  }
  /*
   * @brief 设置四元数
   * @param w 四元数w
   * @param x 四元数x
   * @param y 四元数y
   * @param z 四元数z
   * @note 会从四元数构造欧拉角
   */
  void setQuaternion(const double &w, const double &x, const double &y,
                     const double &z) {
    quaternion_ = Eigen::Quaternionf(w, x, y, z);
    euler_angles_ = quaternion_.toRotationMatrix().eulerAngles(0, 1, 2);
  }
};
```

## PnPSolver类

由于添加了`PHOENIX::Utils::ObjectPointsOf`，`PnPSovler`类不再需要，后续考虑移除

### 定义
  
```cpp
class PnPSolver {
public:
  PnPSolver(const std::array<double, 9> &camera_matrix,
            const std::vector<double> &distortion_coefficients);

  // Get 3d position
  bool solvePnP(const PHOENIX::Utils::Armor &armor, cv::Mat &rvec,
                cv::Mat &tvec);

  // Calculate the distance between armor center and image center
  float calculateDistanceToCenter(const cv::Point2f &image_point);

private:
  cv::Mat camera_matrix_;
  cv::Mat dist_coeffs_;

  // Unit: mm
  static constexpr float SMALL_ARMOR_WIDTH = 135;
  static constexpr float SMALL_ARMOR_HEIGHT = 55;
  static constexpr float LARGE_ARMOR_WIDTH = 225;
  static constexpr float LARGE_ARMOR_HEIGHT = 55;

  // Four vertices of armor in 3d
  std::vector<cv::Point3f> small_armor_points_;
  std::vector<cv::Point3f> large_armor_points_;
};
```

## 卡尔曼滤波

### 基类
```cpp
class KalmanFilter_ {
    public:
	using VecVecFunc =
		std::function<Eigen::VectorXd(const Eigen::VectorXd &)>;
	using VecMatFunc =
		std::function<Eigen::MatrixXd(const Eigen::VectorXd &)>;
	using VoidMatFunc = std::function<Eigen::MatrixXd()>;

	KalmanFilter_(VecVecFunc f, VecMatFunc m_f, VecVecFunc f_h,
		      VecMatFunc m_h, Eigen::MatrixXd Q, Eigen::MatrixXd R,
		      Eigen::MatrixXd p0);
	KalmanFilter_(VecVecFunc f, VecMatFunc m_f, VecVecFunc f_h,
		      VecMatFunc m_h, Eigen::MatrixXd p0);

	virtual Eigen::MatrixXd Update(Eigen::VectorXd z) = 0;
	virtual Eigen::MatrixXd Predict() = 0;

    protected:
	int Dim_; // 状态量维度

	// 状态量
	Eigen::VectorXd X_Crr_; // 当前值
	Eigen::VectorXd X_Pred_; // 预测值
	// 协方差
	Eigen::MatrixXd P_Crr_; // 当前值
	Eigen::MatrixXd P_Pred_; // 预测值

	VecVecFunc f_; // 状态转移函数
	VecMatFunc Matrix_f; // 状态转移函数的雅可比矩阵
	Eigen::MatrixXd F_; // 状态转移矩阵

	Eigen::MatrixXd B_; // 控制矩阵
	Eigen::VectorXd U_; // 控制量

	VecVecFunc h_; // 观测函数
	VecMatFunc Matrix_h; // 观测函数的雅可比矩阵
	Eigen::MatrixXd H_; // 观测矩阵

	// 误差
	Eigen::MatrixXd Q_; // 模型误差
	Eigen::MatrixXd R_; // 观测误差

	// 卡尔曼增益
	Eigen::MatrixXd K_;

	Eigen::MatrixXd I_; // 单位矩阵
};
```

### 经典卡尔曼滤波（KF）
```cpp
class KalmanFilter : public KalmanFilter_ {
    public:
	KalmanFilter(const VecVecFunc &f, const VecMatFunc &m_f,
		     const VecVecFunc &f_h, const VecMatFunc &m_h,
		     const Eigen::MatrixXd &Q, const Eigen::MatrixXd &R,
		     const Eigen::MatrixXd &p0);
	~KalmanFilter() = default;

	void SetState(const Eigen::VectorXd &x0);
	Eigen::MatrixXd Update(Eigen::VectorXd z) override;
	Eigen::MatrixXd Predict() override;

}; // class KalmanFilter
```

### 扩展卡尔曼滤波（EKF）
```cpp
class ExtendedKalmanFilter : public KalmanFilter_ {
	using VoidMatFunc = std::function<Eigen::MatrixXd()>;

    public:
	ExtendedKalmanFilter(const VecVecFunc &f, const VecMatFunc &m_f,
			     const VecVecFunc &f_h, const VecMatFunc &m_h,
			     const VoidMatFunc &u_Q, const VecMatFunc &u_R,
			     const Eigen::MatrixXd &p0);
	~ExtendedKalmanFilter() = default;

	void SetState(const Eigen::VectorXd &x0);
	Eigen::MatrixXd Update(Eigen::VectorXd z) override;
	Eigen::MatrixXd Predict() override;

    private:
	VoidMatFunc update_Q;
	VecMatFunc update_R;

}; // class ExtendedKalmanFilter
```

### 无迹卡尔曼滤波（UKF）
```cpp
class UnscentedKalmanFilter : public KalmanFilter_ {
    public:
	UnscentedKalmanFilter(const VecVecFunc &f, const VecMatFunc &m_f,
			      const VecVecFunc &f_h, const VecMatFunc &m_h,
			      const Eigen::MatrixXd &Q,
			      const Eigen::MatrixXd &R,
			      const Eigen::MatrixXd &p0);
	~UnscentedKalmanFilter() = default;

	void SetState(const Eigen::VectorXd &x0);
	Eigen::MatrixXd Update(Eigen::VectorXd z) override;
	Eigen::MatrixXd Predict() override;

}; // class UnscentedKalmanFilter
```