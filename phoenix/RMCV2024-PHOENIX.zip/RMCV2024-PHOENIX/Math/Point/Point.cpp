#include "Math/Point.hpp"

namespace PHOENIX::Math
{
Point::Point()
    : x(0.0f)
    , y(0.0f)
    , z(0.0f)
{
}

Point::Point(double x, double y, double z)
    : x(x)
    , y(y)
    , z(z)
{
}

Point::Point(const Point &p)
    : x(p.x)
    , y(p.y)
    , z(p.z)
{
}

Point::~Point()
{
}

Point &Point::operator=(const Point &p)
{
    x = p.x;
    y = p.y;
    z = p.z;
    return *this;
}

Point Point::operator+(const Point &p) const
{
    return Point(x + p.x, y + p.y, z + p.z);
}

Point &Point::operator+=(const Point &p)
{
    x += p.x;
    y += p.y;
    z += p.z;
    return *this;
}

Point Point::operator-(const Point &p) const
{
    return Point(x - p.x, y - p.y, z - p.z);
}

Point &Point::operator-=(const Point &p)
{
    x -= p.x;
    y -= p.y;
    z -= p.z;
    return *this;
}

Point Point::operator*(double s) const
{
    return Point(x * s, y * s, z * s);
}

Point &Point::operator*=(double s)
{
    x *= s;
    y *= s;
    z *= s;
    return *this;
}

Point Point::operator/(double s) const
{
    return Point(x / s, y / s, z / s);
}

Point &Point::operator/=(double s)
{
    x /= s;
    y /= s;
    z /= s;
    return *this;
}

bool Point::operator==(const Point &p) const
{
    return x == p.x && y == p.y && z == p.z;
}

bool Point::operator!=(const Point &p) const
{
    return x != p.x || y != p.y || z != p.z;
}

double Point::Length() const
{
    return sqrtf(x * x + y * y + z * z);
}

double Point::LengthSquared() const
{
    return x * x + y * y + z * z;
}

void Point::Normalize()
{
    double length = Length();
    x /= length;
    y /= length;
    z /= length;
}

Point Point::Normalized() const
{
    double length = Length();
    return Point(x / length, y / length, z / length);
}
} // namespace PHOENIX::Math
