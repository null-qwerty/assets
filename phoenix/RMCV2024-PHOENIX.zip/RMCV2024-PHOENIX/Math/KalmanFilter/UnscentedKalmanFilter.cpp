#include "Math/KalmanFilter.hpp"

namespace PHOENIX::Math
{
UnscentedKalmanFilter::UnscentedKalmanFilter(
    const VecVecFunc &f, const VecMatFunc &m_f, const VecVecFunc &f_h,
    const VecMatFunc &m_h, const Eigen::MatrixXd &Q, const Eigen::MatrixXd &R,
    const Eigen::MatrixXd &p0)
    : KalmanFilter_(f, m_f, f_h, m_h, Q, R, p0)
    , sigma_points_(Eigen::MatrixXd::Zero(Dim_, 2 * Dim_ + 1))
    , predicted_sigma_points_(Eigen::MatrixXd::Zero(Dim_, 2 * Dim_ + 1))
    , y_(Eigen::VectorXd::Zero(Dim_))
    , mean_(Eigen::VectorXd::Zero(Dim_))
    , covariance_(Eigen::MatrixXd::Zero(Dim_, Dim_))
{
}

Eigen::MatrixXd UnscentedKalmanFilter::Predict()
{
    L_ = P_Crr_.llt().matrixL();
    /*
   * @brief 计算sigma点
   * @param X_crr 当前状态
   */
    sigma_points_.col(0) = X_Crr_;
    for (int i = 0; i < Dim_; ++i) {
        sigma_points_.col(i + 1) = X_Crr_ + sqrt(3) * L_.col(i);
        sigma_points_.col(i + 1 + Dim_) = X_Crr_ - sqrt(3) * L_.col(i);
    }
    // 生成sigma矩阵
    for (int i = 0; i < 2 * Dim_ + 1; ++i) {
        predicted_sigma_points_.col(i) = f_(sigma_points_.col(i));
    }
    // 计算预测均值和协方差
    mean_.setZero();
    double a = (3.0 - Dim_) / 3;
    for (int i = 0; i < 2 * Dim_ + 1; ++i) {
        mean_ += a * predicted_sigma_points_.col(i);
        a = 1.0 / 6;
    }

    covariance_.setZero();
    a = (3.0 - Dim_) / 3;
    for (int i = 0; i < 2 * Dim_ + 1; ++i) {
        auto diff = predicted_sigma_points_.col(i) - mean_;
        covariance_ += a * diff * diff.transpose();
        a = 1.0 / 6;
    }
    covariance_ += Q_;

    X_Pred_ = mean_;
    P_Pred_ = covariance_;

    return X_Pred_;
}

Eigen::MatrixXd UnscentedKalmanFilter::Update(Eigen::VectorXd z)
{
    //生成新的sigma矩阵
    Eigen::MatrixXd S = Eigen::MatrixXd::Zero(Dim_, 2 * Dim_ + 1);
    for (int i = 0; i < 2 * Dim_ + 1; ++i)
        S.col(i) = h_(predicted_sigma_points_.col(i));

    y_.setZero();
    double a = (3.0 - Dim_) / 3;
    for (int i = 0; i < 2 * Dim_ + 1; ++i) {
        y_ += a * S.col(i);
        a = 1.0 / 6;
    }

    covariance_.setZero();
    a = (3.0 - Dim_) / 3;
    for (int i = 0; i < 2 * Dim_ + 1; ++i) {
        auto diff = S.col(i) - y_;
        covariance_ += a * diff * diff.transpose();
        a = 1.0 / 6;
    }

    covariance_ += R_;

    Eigen::MatrixXd Pxy = Eigen::MatrixXd::Zero(Dim_, Dim_);

    a = (3.0 - Dim_) / 3;
    for (int i = 0; i < 2 * Dim_ + 1; ++i) {
        Pxy += a * (predicted_sigma_points_.col(i) - mean_) *
               (S.col(i) - y_).transpose();
        a = 1.0 / 6;
    }

    K_ = Pxy * covariance_.inverse();

    X_Crr_ = X_Pred_ + K_ * (z - y_);
    P_Crr_ = P_Pred_ - K_ * covariance_ * K_.transpose();

    return X_Crr_;
}

} // namespace PHOENIX::Math
