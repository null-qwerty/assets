#include "Math/KalmanFilter.hpp"
#include <iostream>

namespace PHOENIX::Math
{
// 构造函数的实现
ExtendedKalmanFilter::ExtendedKalmanFilter(
    const VecVecFunc &f, const VecMatFunc &m_f, const VecVecFunc &f_h,
    const VecMatFunc &m_h, const VoidMatFunc &u_Q, const VecMatFunc &u_R,
    const Eigen::MatrixXd &p0)
    : KalmanFilter_(f, m_f, f_h, m_h, p0)
    , update_Q(u_Q)
    , update_R(u_R)
{
}

// 设置初始状态的实现
void ExtendedKalmanFilter::SetState(const Eigen::VectorXd &x0)
{
    X_Crr_ = x0;
}

// 预测方法的实现
Eigen::MatrixXd ExtendedKalmanFilter::Predict()
{
    F_ = Matrix_f(X_Crr_), Q_ = update_Q();

    X_Pred_ = f_(X_Crr_);
    P_Pred_ = F_ * P_Crr_ * F_.transpose() + Q_;

    // 处理在下一次预测之前没有测量的情况
    X_Crr_ = X_Pred_;
    P_Crr_ = P_Pred_;

    return X_Pred_;
}

// 更新方法的实现
Eigen::MatrixXd ExtendedKalmanFilter::Update(Eigen::VectorXd z)
{
    H_ = Matrix_h(X_Pred_), R_ = update_R(z);
    K_ = P_Pred_ * H_.transpose() *
         (H_ * P_Pred_ * H_.transpose() + R_).inverse();
    X_Crr_ = X_Pred_ + K_ * (z - h_(X_Pred_));
    P_Crr_ = (I_ - K_ * H_) * P_Pred_;
    return X_Crr_;
}

} // namespace PHOENIX::Math
