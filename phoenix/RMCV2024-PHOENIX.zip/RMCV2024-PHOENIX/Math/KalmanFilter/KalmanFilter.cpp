#include "Math/KalmanFilter.hpp"
#include <iostream>

namespace PHOENIX::Math
{
KalmanFilter_::KalmanFilter_(VecVecFunc f, VecMatFunc m_f, VecVecFunc f_h,
                             VecMatFunc m_h, Eigen::MatrixXd Q,
                             Eigen::MatrixXd R, Eigen::MatrixXd p0)
    : f_(f)
    , Matrix_f(m_f)
    , h_(f_h)
    , Matrix_h(m_h)
    , Q_(Q)
    , R_(R)
    , P_Crr_(p0)
    , Dim_(p0.cols())
    , I_(Eigen::MatrixXd::Identity(p0.cols(), p0.cols()))
    , X_Crr_(Dim_)
    , X_Pred_(Dim_)
    , P_Pred_(Dim_, Dim_)
{
}

KalmanFilter_::KalmanFilter_(VecVecFunc f, VecMatFunc m_f, VecVecFunc f_h,
                             VecMatFunc m_h, Eigen::MatrixXd p0)
    : f_(f)
    , Matrix_f(m_f)
    , h_(f_h)
    , Matrix_h(m_h)
    , Q_(Eigen::MatrixXd::Identity(p0.cols(), p0.cols()))
    , R_(Eigen::MatrixXd::Identity(p0.cols(), p0.cols()))
    , P_Crr_(p0)
    , Dim_(p0.cols())
    , I_(Eigen::MatrixXd::Identity(p0.cols(), p0.cols()))
    , X_Crr_(Dim_)
    , X_Pred_(Dim_)
    , P_Pred_(Dim_, Dim_)
{
}
KalmanFilter::KalmanFilter(const VecVecFunc &f, const VecMatFunc &m_f,
                           const VecVecFunc &f_h, const VecMatFunc &m_h,
                           const Eigen::MatrixXd &Q, const Eigen::MatrixXd &R,
                           const Eigen::MatrixXd &p0)
    : KalmanFilter_(f, m_f, f_h, m_h, Q, R, p0)
{
}

void KalmanFilter::SetState(const Eigen::VectorXd &x0)
{
    X_Crr_ = x0;
}

Eigen::MatrixXd KalmanFilter::Predict()
{
    X_Pred_ = f_(X_Crr_);
    F_ = Matrix_f(X_Crr_);
    P_Pred_ = F_ * P_Crr_ * F_.transpose() + Q_;
    return X_Pred_;
}

Eigen::MatrixXd KalmanFilter::Update(Eigen::VectorXd z)
{
    H_ = Matrix_h(X_Pred_);
    Eigen::VectorXd y = z - h_(X_Pred_);
    Eigen::MatrixXd S = H_ * P_Pred_ * H_.transpose() + R_;
    K_ = P_Pred_ * H_.transpose() * S.inverse(); // 卡尔曼增益
    // 下一次状态的变化
    X_Crr_ = X_Pred_ + K_ * y;
    P_Crr_ = (I_ - K_ * H_) * P_Pred_;
    return X_Crr_;
}
} // namespace PHOENIX::Math