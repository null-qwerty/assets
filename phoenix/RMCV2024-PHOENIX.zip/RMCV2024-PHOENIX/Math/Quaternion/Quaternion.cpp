#include "Math/Quaternion.hpp"

namespace PHOENIX::Math
{
Quaternion::Quaternion()
    : x(0.0f)
    , y(0.0f)
    , z(0.0f)
    , w(1.0f)
{
}

Quaternion::Quaternion(double x, double y, double z, double w)
    : x(x)
    , y(y)
    , z(z)
    , w(w)
{
}

Quaternion::Quaternion(const Quaternion &q)
    : x(q.x)
    , y(q.y)
    , z(q.z)
    , w(q.w)
{
}

Quaternion::Quaternion(double yaw, double pitch, double roll)
{
    double cy = cosf(yaw * 0.5f);
    double sy = sinf(yaw * 0.5f);
    double cp = cosf(pitch * 0.5f);
    double sp = sinf(pitch * 0.5f);
    double cr = cosf(roll * 0.5f);
    double sr = sinf(roll * 0.5f);

    w = cr * cp * cy + sr * sp * sy;
    x = sr * cp * cy - cr * sp * sy;
    y = cr * sp * cy + sr * cp * sy;
    z = cr * cp * sy - sr * sp * cy;
}

Quaternion::~Quaternion()
{
}

Quaternion &Quaternion::operator=(const Quaternion &q)
{
    x = q.x;
    y = q.y;
    z = q.z;
    w = q.w;
    return *this;
}

Quaternion Quaternion::operator*(const Quaternion &q) const
{
    return Quaternion(w * q.x + x * q.w + y * q.z - z * q.y,
                      w * q.y + y * q.w + z * q.x - x * q.z,
                      w * q.z + z * q.w + x * q.y - y * q.x,
                      w * q.w - x * q.x - y * q.y - z * q.z);
}

Quaternion &Quaternion::operator*=(const Quaternion &q)
{
    *this = *this * q;
    return *this;
}

Quaternion Quaternion::operator*(double s) const
{
    return Quaternion(x * s, y * s, z * s, w * s);
}

Quaternion &Quaternion::operator*=(double s)
{
    x *= s;
    y *= s;
    z *= s;
    w *= s;
    return *this;
}

Quaternion Quaternion::operator+(const Quaternion &q) const
{
    return Quaternion(x + q.x, y + q.y, z + q.z, w + q.w);
}

Quaternion &Quaternion::operator+=(const Quaternion &q)
{
    x += q.x;
    y += q.y;
    z += q.z;
    w += q.w;
    return *this;
}

Quaternion Quaternion::operator-(const Quaternion &q) const
{
    return Quaternion(x - q.x, y - q.y, z - q.z, w - q.w);
}

Quaternion &Quaternion::operator-=(const Quaternion &q)
{
    x -= q.x;
    y -= q.y;
    z -= q.z;
    w -= q.w;
    return *this;
}

Quaternion Quaternion::operator/(double s) const
{
    return Quaternion(x / s, y / s, z / s, w / s);
}

Quaternion &Quaternion::operator/=(double s)
{
    x /= s;
    y /= s;
    z /= s;
    w /= s;
    return *this;
}

bool Quaternion::operator==(const Quaternion &q) const
{
    return x == q.x && y == q.y && z == q.z && w == q.w;
}

bool Quaternion::operator!=(const Quaternion &q) const
{
    return x != q.x || y != q.y || z != q.z || w != q.w;
}

double Quaternion::Length() const
{
    return sqrtf(x * x + y * y + z * z + w * w);
}

double Quaternion::LengthSquared() const
{
    return x * x + y * y + z * z + w * w;
}

void Quaternion::Normalize()
{
    double len = Length();
    x /= len;
    y /= len;
    z /= len;
    w /= len;
}

Quaternion Quaternion::Normalized() const
{
    double len = Length();
    return Quaternion(x / len, y / len, z / len, w / len);
}

void Quaternion::Conjugate()
{
    x = -x;
    y = -y;
    z = -z;
}

Quaternion Quaternion::Conjugated() const
{
    return Quaternion(-x, -y, -z, w);
}

void Quaternion::Invert()
{
    Conjugate();
    double len = LengthSquared();
    x /= len;
    y /= len;
    z /= len;
    w /= len;
}

Quaternion Quaternion::Inverted() const
{
    Quaternion q = Conjugated();
    double len = LengthSquared();
    return Quaternion(q.x / len, q.y / len, q.z / len, q.w / len);
}

void Quaternion::ToEuler(double &yaw, double &pitch, double &roll)
{
    double ysqr = y * y;

    // roll (x-axis rotation)
    double t0 = +2.0f * (w * x + y * z);
    double t1 = +1.0f - 2.0f * (x * x + ysqr);
    roll = atan2f(t0, t1);

    // pitch (y-axis rotation)
    double t2 = +2.0f * (w * y - z * x);
    t2 = t2 > 1.0f ? 1.0f : t2;
    t2 = t2 < -1.0f ? -1.0f : t2;
    pitch = asinf(t2);

    // yaw (z-axis rotation)
    double t3 = +2.0f * (w * z + x * y);
    double t4 = +1.0f - 2.0f * (ysqr + z * z);
    yaw = atan2f(t3, t4);
}
} // namespace PHOENIX::Math