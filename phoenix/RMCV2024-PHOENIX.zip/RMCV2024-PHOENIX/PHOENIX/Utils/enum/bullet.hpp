#pragma once

namespace PHOENIX::Utils
{
enum Bullet { Small, Large, Light };
}