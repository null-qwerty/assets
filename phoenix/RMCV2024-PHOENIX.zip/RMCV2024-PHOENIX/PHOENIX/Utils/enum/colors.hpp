#pragma once

namespace PHOENIX::Utils
{
enum COLOR { RED, BLUE };
}