#pragma once

#include <opencv2/core.hpp>

#include <algorithm>
#include <string>

namespace PHOENIX::Utils
{

struct Light : public cv::RotatedRect {
    Light() = default;
    explicit Light(cv::RotatedRect box);

    int color;
    cv::Point2f top, bottom;
    double length;
    double width;
    float tilt_angle;
};
} // namespace PHOENIX::Utils