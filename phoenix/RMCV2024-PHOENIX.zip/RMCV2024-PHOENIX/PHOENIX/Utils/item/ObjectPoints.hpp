#pragma once
#include <vector>
#include <opencv2/opencv.hpp>

namespace PHOENIX::Utils::ObjectPointsOf
{
// Unit: mm
static constexpr float SMALL_ARMOR_WIDTH = 135;
static constexpr float SMALL_ARMOR_HEIGHT = 55;
static constexpr float LARGE_ARMOR_WIDTH = 225;
static constexpr float LARGE_ARMOR_HEIGHT = 55;
static constexpr float EXCHANGE_STATION_SIZE = 288;
// Unit: m
static constexpr float SMALL_ARMOR_WIDTH_HALF = SMALL_ARMOR_WIDTH / 2.0 / 1000;
static constexpr float SMALL_ARMOR_HEIGHT_HALF =
    SMALL_ARMOR_HEIGHT / 2.0 / 1000;
static constexpr float LARGE_ARMOR_WIDTH_HALF = LARGE_ARMOR_WIDTH / 2.0 / 1000;
static constexpr float LARGE_ARMOR_HEIGHT_HALF =
    LARGE_ARMOR_HEIGHT / 2.0 / 1000;
static constexpr float EXCHANGE_STATION_SIZE_HALF =
    EXCHANGE_STATION_SIZE / 2.0 / 1000;

// 左下角为原点，顺时针
const std::vector<cv::Point3f> small_armor(
    { cv::Point3f(0, SMALL_ARMOR_WIDTH_HALF, -SMALL_ARMOR_HEIGHT_HALF),
      cv::Point3f(0, SMALL_ARMOR_WIDTH_HALF, SMALL_ARMOR_HEIGHT_HALF),
      cv::Point3f(0, -SMALL_ARMOR_WIDTH_HALF, SMALL_ARMOR_HEIGHT_HALF),
      cv::Point3f(0, -SMALL_ARMOR_WIDTH_HALF, -SMALL_ARMOR_HEIGHT_HALF) });

// 左下角为原点，顺时针
const std::vector<cv::Point3f> large_armor(
    { cv::Point3f(0, LARGE_ARMOR_WIDTH_HALF, -LARGE_ARMOR_HEIGHT_HALF),
      cv::Point3f(0, LARGE_ARMOR_WIDTH_HALF, LARGE_ARMOR_HEIGHT_HALF),
      cv::Point3f(0, -LARGE_ARMOR_WIDTH_HALF, LARGE_ARMOR_HEIGHT_HALF),
      cv::Point3f(0, -LARGE_ARMOR_WIDTH_HALF, -LARGE_ARMOR_HEIGHT_HALF) });

// 右上角为原点，逆时针
const std::vector<cv::Point3f> exchange_station(
    { cv::Point3f(0, -EXCHANGE_STATION_SIZE_HALF, EXCHANGE_STATION_SIZE_HALF),
      cv::Point3f(0, EXCHANGE_STATION_SIZE_HALF, EXCHANGE_STATION_SIZE_HALF),
      cv::Point3f(0, EXCHANGE_STATION_SIZE_HALF, -EXCHANGE_STATION_SIZE_HALF),
      cv::Point3f(0, -EXCHANGE_STATION_SIZE_HALF,
                  -EXCHANGE_STATION_SIZE_HALF) });
}