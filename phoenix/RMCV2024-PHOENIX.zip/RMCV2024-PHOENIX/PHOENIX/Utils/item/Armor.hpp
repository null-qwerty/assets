#pragma once

#ifdef USE_MKL
#define EIGEN_USE_MKL_ALL
#define EIGEN_VECTORIZE_AVX256
#endif

#include <eigen3/Eigen/Core>
#include "Math/Pose.hpp"
#include "Utils/item/Light.hpp"

namespace PHOENIX::Utils
{

enum class ArmorType { SMALL, LARGE, INVALID };

struct Armor {
    Armor() = default;
    Armor(const Light &l1, const Light &l2);

    // Light pairs part
    Light left_light, right_light;
    cv::Point2f center;
    ArmorType type;

    // Number part
    cv::Mat number_img;
    std::string number;
    float confidence;
    std::string classfication_result;
    float distance_to_image_center;
    PHOENIX::Math::Pose pose;
};

}