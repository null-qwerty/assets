#pragma once

#include "Armor.hpp"
#include "Light.hpp"
#include "ObjectPoints.hpp"