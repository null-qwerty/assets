#include <chrono>

namespace PHOENIX::Utils::Timestamp
{
time_t getTimestamp();
}