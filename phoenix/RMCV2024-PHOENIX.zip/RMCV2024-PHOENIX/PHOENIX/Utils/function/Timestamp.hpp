#include <chrono>

namespace PHOENIX::Utils::Timestamp
{
/**
 * @brief 获取时间戳
 * 
 * @return time_t 时间戳
 */
time_t getTimestamp();
}