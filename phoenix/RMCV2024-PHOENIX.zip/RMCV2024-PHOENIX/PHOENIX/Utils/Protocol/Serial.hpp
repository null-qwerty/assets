#pragma once
#include <stdint.h>

namespace PHOENIX::Utils::SerialProtocol
{
#pragma pack(1)

/*
 * @param car_name: 兵种名称
 * @param type_size: 自定义消息类型大小，除去头尾
 */
#define CostumType(car_name, buffer_size)  \
    typedef union {                        \
        struct {                           \
            uint8_t start = 's';           \
            uint8_t buffer[type_size - 2]; \
            uint8_t end = 'e';             \
        } data;                            \
        uint8_t *buffer;                   \
    } car_name;

/*
 * @tparam dataTp: 数据包除去头尾的数据结构
 */
template <typename dataTp> union TemplateProtocol {
    struct {
        uint8_t start = 's';
        dataTp data;
        uint8_t end = 'e';
    };
    uint8_t *buffer;
};

typedef union SentinalProtocol { // 哨兵上下位机通信协议
    struct {
        uint8_t start = 's'; //  0 帧头，取 's’
        uint8_t type; //  1 消息类型
        /* type 取值：
                          *       上位机发下位机
                          *      0xA0     底盘控制
                          *      0xA1     云台控制
                          *      0xA2     射击控制
                          *       下位机发上位机
                          *      0xB0     底盘反馈
                          *      0xB1     位移信息
                          *      0xB2     云台陀螺仪信息
                          *      0xB3     比赛信息
                          *      0xB4     位置信息
                          */
        uint8_t buffer[29]; //  2 ~ 30 数据
        uint8_t end = 'e'; // 31 帧尾，取 'e'
    } data;
    uint8_t *buffer;
} Sentinal;

typedef union InfantrySendProtocol { // 步兵上下位机通信发送协议
    struct {
        char start = 's'; // 0         开始位(s)
        char is_find; // 1         是否找到目标
        char can_shoot; // 2         是否可以射击
        float yaw; // 3 ~ 6     yaw 偏移量
        float pitch; // 7 ~ 10    pitch 偏移量
        float origin_yaw; // 11 ~ 14   接收到的 yaw
        float origin_pitch; // 15 ~ 18   接收到的 pitch
        float distance; // 19 ~ 22   目标距离
        char mode; // 23        模式 装甲板：a  符：r
        int id = -1; // 24 ~ 27     ？
        char unused[3] = {}; // 28 ~ 30     预留位
        char end = 'e'; // 31        结束位
    } data;
    uint8_t *buffer;
} InfantrySend;

typedef union InfantryRecvProtocol { // 步兵上下位机通信接收协议
    struct {
        char start = 's'; // 0       开始位
        char color; // 1       颜色
        char mode; // 2       模式 装甲板：a  符：r
        float speed = 20; // 3 ~ 6   速度
        float euler[3] = {}; // 7 ~ 24    欧拉角 (0,1,2) = (yaw,roll,pitch)
        char shoot_bool = 0; // 25
        char rune_flag = 0; // 26      0为不可激活，1为小符，2为大符
        char unused[10] = {}; // 27 ~ 30
        char end = 'e'; // 31
    } data;
    uint8_t *buffer;
} InfantryRecv;

typedef union HeroSendProtocol { // 英雄上下位机通信发送协议
    struct {
        char start = 's'; // 0         开始位(s)
        char is_find; // 1         是否找到目标
        char can_shoot; // 2         是否可以射击
        float yaw; // 3 ~ 6     yaw 偏移量
        float pitch; // 7 ~ 10    pitch 偏移量
        float origin_yaw; // 11 ~ 14   接收到的 yaw
        float origin_pitch; // 15 ~ 18   接收到的 pitch
        float distance; // 19 ~ 22   目标距离
        char mode; // 23        模式 装甲板：a  符：r
        int id = -1; // 24 ~ 27     ？
        char unused[3] = {}; // 28 ~ 30     预留位
        char end = 'e'; // 31        结束位
    } data;
    uint8_t *buffer;
} HeroSend;

typedef union HeroRecvProtocol { // 英雄上下位机通信接收协议
    struct {
        char start = 's'; // 0       开始位
        char color; // 1       颜色
        char mode; // 2       模式 装甲板：a  符：r
        float speed = 20; // 3 ~ 6   速度
        float euler[3] = {}; // 7 ~ 24    欧拉角 (0,1,2) = (yaw,roll,pitch)
        char shoot_bool = 0; // 25
        char rune_flag = 0; // 26      0为不可激活，1为小符，2为大符
        char unused[10] = {}; // 27 ~ 30
        char end = 'e'; // 31
    } data;
    uint8_t *buffer;
} HeroRecv;

typedef union AirplaneProtocol { // 飞机上下位机通信协议
    struct {
        uint8_t start;
        uint8_t buffer[30];
        uint8_t end;
    } data;
    uint8_t *buffer;
} Airplane;

typedef union EngineerProtocol { // 工程上下位机通信协议
    struct {
        uint8_t start;
        uint8_t buffer[30];
        uint8_t end;
    } data;
    uint8_t *buffer;
} Engineer;

#pragma pack()
} // namespace PHOENIX::Protocol::Serial