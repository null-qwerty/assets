#pragma once

#include <iostream>
#include <string>
#include <vector>

namespace PHOENIX::Utils::IPCProtocol
{
#pragma pack(1)

/**
 * @param type_name: 自定义消息类型名称,
 * 最后创建的结构名称会在type_name后加上Msg
 * @param type_size: 自定义消息类型大小
 */
#define CostumType(type_name, type_size) \
    typedef struct {                     \
        time_t timestamp;                \
        uint8_t data[type_size];         \
    } type_name##Msg;

/**
 * @tparam dataTp: 数据的结构
 */
template <typename dataTp> struct TemplateMsg {
    time_t timestamp;
    dataTp data;
};

typedef struct Int32ArrayProtocol_s {
    time_t timestamp;
    std::vector<int> data;
} IntArrayMsg;

typedef struct Float32ArrayProtocol_s {
    time_t timestamp;
    std::vector<float> data;
} Float32ArrayMsg;

typedef struct TransformProtocol_s {
    time_t timestamp;
    char from[50];
    char to[50];
    double translation[3];
    double rotation[4];
} TransformMsg;

#pragma pack()
} // namespace PHOENIX::Protocol::IPCProtocol