#pragma once

#include <opencv2/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#include "Utils/enum/colors.hpp"

namespace PHOENIX::CVlib
{

/**
 * @brief 图像预处理
 * @param origin_frame 原始图像
 * @param result 二值化图像
 * @param detect_color 需要识别的颜色
 * @param threshold 二值化阈值
 * @param blue_threshold 蓝色通道二值化阈值 default: 200
 * @param red_threshold 红色通道二值化阈值  default: 100
 * @param morph 是否进行开运算 default: true
 * @param blur 是否进行高斯模糊 default: true
 */
void ImagePreprocessing(cv::Mat &origin_frame, cv::Mat &result,
                        PHOENIX::Utils::COLOR detect_color, int threshold,
                        int blue_threshold = 200, int red_threshold = 100,
                        bool morph = true, bool blur = true);
/**
 * @brief 获取相机内参
 * @param cameraMatrix 相机内参
 * @param distCoeffs 相机畸变参数
 * @param FilePath 相机内参文件路径
 */
void getCameraParm(cv::Mat &cameraMatrix, cv::Mat &distCoeffs,
                   std::string FilePath = "../config/camera.yml");
} // namespace PHOENIX::cvlib