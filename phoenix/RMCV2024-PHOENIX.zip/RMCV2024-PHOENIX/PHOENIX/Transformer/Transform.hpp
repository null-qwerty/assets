#pragma once

#ifdef USE_MKL
#define EIGEN_USE_MKL_ALL
#define EIGEN_VECTORIZE_AVX256
#endif

#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Geometry>

namespace PHOENIX
{
struct Transform {
    Eigen::Vector3d translation;
    Eigen::Quaterniond rotation;

    Transform() = default;
    /**
     * @brief 构造一个坐标系变换
     * @param translation 平移向量
     * @param rotation 旋转四元数
    */
    Transform(const Eigen::Vector3d &translation,
              const Eigen::Quaterniond &rotation);
    ~Transform() = default;

    Transform operator-(const Transform &other) const;
    Transform operator-() const;
    Transform operator+(const Transform &other) const;
    Transform operator=(const Transform &other);
    bool operator==(const Transform &other) const;
    bool operator!=(const Transform &other) const
    {
        return !(*this == other);
    }
};

const Transform TRANSFORM_NOT_FOUND =
    Transform(Eigen::Vector3d(0, 0, 0), Eigen::Quaterniond(0, 0, 0, 0));
const Transform TRANSFORM_TO_SELF =
    Transform(Eigen::Vector3d(0, 0, 0), Eigen::Quaterniond(1, 0, 0, 0));
const Transform TRANSFORM_BUFFER_EMPTY =
    Transform(Eigen::Vector3d(0, 0, 0), Eigen::Quaterniond(2, 0, 0, 0));
}