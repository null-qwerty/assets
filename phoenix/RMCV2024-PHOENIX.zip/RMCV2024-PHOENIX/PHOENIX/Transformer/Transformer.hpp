#pragma once

#include "Transformer/TransformBuffer.hpp"

#include <IPC-framework/SHM_SYSV.hpp>
#include <IPC-framework/Config.hpp>
#include <IPC-framework/Transceiver.hpp>

#include <thread>
namespace PHOENIX
{
class TransformPublisher {
private:
    Config::Config cfg;

    Transceiver::Transmitter transmitter;

public:
    TransformPublisher();
    ~TransformPublisher();
    void publish(const std::string &from, const std::string &to,
                 const Transform &transform);
};

class TransformSubscriber : public TransformBuffer {
private:
    Config::Config cfg;
    Transceiver::Receiver receiver;
    std::thread receiverThread;

    void receive();
public:
    TransformSubscriber(int duration = 1);
    ~TransformSubscriber();
};
} // namespace PHOENIX