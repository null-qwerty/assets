#pragma once

#include "Transformer/TransformBuffer.hpp"

#include <IPC-framework/SHM_SYSV.hpp>
#include <IPC-framework/Config.hpp>
#include <IPC-framework/Transceiver.hpp>

#include <thread>
namespace PHOENIX
{
class TransformPublisher {
private:
    Config::Config cfg;

    Transceiver::Transmitter transmitter;

public:
    /**
     * @brief TransformPublisher构造函数
     */
    TransformPublisher();
    ~TransformPublisher();

    /**
     * @brief 发布变换
     * 
     * @param from 变换的起始坐标系
     * @param to 变换的目标坐标系
     * @param transform 变换
     */
    void publish(const std::string &from, const std::string &to,
                 const Transform &transform);
};

class TransformSubscriber : public TransformBuffer {
private:
    Config::Config cfg;
    Transceiver::Receiver receiver;
    std::thread receiverThread;

    void receive();
public:

    /**
     * @brief TransformSubscriber构造函数
     * 
     * @param buffer_size 缓冲区大小
     */
    TransformSubscriber(int buffer_size = 10);
    ~TransformSubscriber();
};
} // namespace PHOENIX