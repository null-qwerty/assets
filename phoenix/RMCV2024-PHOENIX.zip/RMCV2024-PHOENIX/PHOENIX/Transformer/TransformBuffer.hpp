#pragma once

#include <memory>
#include <map>
#include <mutex>
#include <shared_mutex>
#include <thread>

#include "Transformer/TransformTree.hpp"

namespace PHOENIX
{
class TransformBuffer {
private:
    std::map<long, TransformTree> buffer;

    void DeleteExpiredTransform();

protected:
    mutable std::shared_mutex mutex;
    long duration;

    void addTransform(long timestamp, const std::string &from,
                      const std::string &to, const Eigen::Vector3d &translation,
                      const Eigen::Quaterniond &rotation);

    void addTransform(long timestamp, const std::string &from,
                      const std::string &to, const Transform &transform);

public:
    TransformBuffer(long duration = 1);
    ~TransformBuffer();

    /**
     * @brief 获取一个坐标系变换
     * @param timestamp 时间戳
     * @param from 变换前的坐标系
     * @param to 变换后的坐标系
     * @return 变换后的坐标系相对于变换前的坐标系的转换关系
    */
    Transform getTransform(const long timestamp, const std::string &from,
                           const std::string &to);
};
}