#pragma once

#include <unordered_map>
#include <utility>
#include "Transformer/Transform.hpp"

namespace PHOENIX
{
typedef std::unordered_map<std::string,
                           std::unordered_map<std::string, Transform>>
    TransformTree_;

class TransformTree {
private:
    TransformTree_ buffer;
    std::unordered_map<std::string, bool> flag = {};

public:
    TransformTree() = default;
    ~TransformTree() = default;

    /**
     * @brief 添加一个坐标系变换
     * @param from 变换前的坐标系
     * @param to 变换后的坐标系
     * @param translation 平移向量
     * @param rotation 旋转四元数
    */
    void addTransform(const std::string &from, const std::string &to,
                      const Eigen::Vector3d &translation,
                      const Eigen::Quaterniond &rotation);

    /**
     * @brief 添加一个坐标系变换
     * @param from 变换前的坐标系
     * @param to 变换后的坐标系
     * @param transform 变换后的坐标系相对于变换前的坐标系的转换关系
    */
    void addTransform(const std::string &from, const std::string &to,
                      const Transform &transform);

    /**
     * @brief 获取一个坐标系变换
     * @param from 变换前的坐标系
     * @param to 变换后的坐标系
     * @return 变换后的坐标系相对于变换前的坐标系的转换关系
    */
    Transform getTransform(const std::string &from, const std::string &to);
};
} // namespace PHOENIX