#pragma once

#include "CameraApi.h"
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc_c.h"
#include "opencv2/opencv.hpp"

namespace PHOENIX
{
class Camera {
private:
    unsigned char *g_pRgbBuffer; // 处理后数据缓存区
    int iCameraCounts = 1;
    int iStatus = -1;
    tSdkCameraDevInfo tCameraEnumList;
    int hCamera;
    tSdkCameraCapbility tCapability; // 设备描述信息
    tSdkFrameHead sFrameInfo;
    BYTE *pbyBuffer;
    IplImage *iplImage = NULL;
    int channel = 3;

    // 相机参数设置
    int AutoExposure = 0; // 自动曝光
    int ExposureTime = 2000; // 曝光时间
    int AutoWhiteBalance = 1; // 自动白平衡
    int Contrast = 100; // 对比度

    std::string ConfigPath;
    bool useConfigFile = false;

    cv::Matx33d cameraMatrix;
    cv::Matx<double, 5, 1> distCoeffs;
    bool setCameraMatrix;

public:
    /**
    * @brief Mindvision Camera 类构造函数
    * @param AutoExposure 设置自动曝光，0为关闭，1为打开
    * @param ExposureTime 曝光时间，单位为微秒
    * @param AutoWhiteBalance 白平衡，0为关闭，1为打开
    * @param Contrast 对比度
    * @param ConfigPath 配置文件路径，若设置则使用配置文件，前面的参数无效
    */
    Camera(int AutoExposure = 0, int ExposureTime = 2000,
           int AutoWhiteBalance = 1, int Contrast = 100, std::string ConfigPath = "");
    /**
     * @brief Mindvision Camera 类构造函数
     * @param cameraMatrix 相机内参矩阵
     * @param distCoeffs 相机畸变参数
     * @param ExposureTime 曝光时间，单位为微秒
    */
    Camera(cv::InputArray &cameraMatrix, cv::InputArray &distCoeffs,
           int ExposureTime = 2000);
    ~Camera();
    void init();
    void getFrame(std::shared_ptr<cv::Mat> &frame);
    void close();
    void releasebuffer();
};
} // namespace PHOENIX