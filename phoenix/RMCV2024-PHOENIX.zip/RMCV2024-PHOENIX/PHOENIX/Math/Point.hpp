#pragma once

#include <cmath>
#include <vector>

namespace PHOENIX::Math
{
class Point {
public:
    Point();
    Point(double x, double y, double z);
    Point(const Point &p);
    ~Point();

    Point &operator=(const Point &p);
    Point operator+(const Point &p) const;
    Point &operator+=(const Point &p);
    Point operator-(const Point &p) const;
    Point &operator-=(const Point &p);
    Point operator*(double s) const;
    Point &operator*=(double s);
    Point operator/(double s) const;
    Point &operator/=(double s);
    bool operator==(const Point &p) const;
    bool operator!=(const Point &p) const;

    double Length() const;
    double LengthSquared() const;
    void Normalize();
    Point Normalized() const;

private:
    double x, y, z;
};

typedef Point Point3d;
typedef std::vector<Point> Points;

} // namespace PHOENIX::Math