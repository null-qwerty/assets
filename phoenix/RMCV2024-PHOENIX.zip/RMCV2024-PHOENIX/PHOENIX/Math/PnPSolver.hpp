#pragma once

#include "Utils/item/Armor.hpp"
#include "Pose.hpp"
#include <opencv2/core.hpp>

#include <array>
#include <vector>

namespace PHOENIX::Math
{

class PnPSolver {
public:
    /**
     * @brief pnp解算器构造函数
     * 
     * @param camera_matrix 相机内参矩阵
     * @param distortion_coefficients 相机畸变系数
     */
    PnPSolver(const std::array<double, 9> &camera_matrix,
              const std::vector<double> &distortion_coefficients);

    /**
     * @brief pnp解算
     * 
     * @param armor 装甲板
     * @param rvec 旋转向量
     * @param tvec 平移向量
     * @return true
     * @return false
     */
    bool solvePnP(const PHOENIX::Utils::Armor &armor, cv::Mat &rvec,
                  cv::Mat &tvec);

    /**
     * @brief pnp解算
     * 
     * @param objectPoints 物体实际尺寸
     * @param imagePoints 图像上的点
     * @param rvec 旋转向量
     * @param tvec 平移向量
     * @return true
     * @return false 
     */
    bool solvePnP(std::vector<cv::Point3f> &objectPoints,
                  std::vector<cv::Point3f> &imagePoints, cv::Mat &rvec,
                  cv::Mat &tvec);

    /**
     * @brief 计算装甲板到图像中心的距离
     * 
     * @param image_point 图像上的点
     * @return float 装甲板到图像中心的距离
     */
    float calculateDistanceToCenter(const cv::Point2f &image_point);

private:
    cv::Mat camera_matrix_;
    cv::Mat dist_coeffs_;

    // Unit: mm
    static constexpr float SMALL_ARMOR_WIDTH = 135;
    static constexpr float SMALL_ARMOR_HEIGHT = 55;
    static constexpr float LARGE_ARMOR_WIDTH = 225;
    static constexpr float LARGE_ARMOR_HEIGHT = 55;

    // Four vertices of armor in 3d
    std::vector<cv::Point3f> small_armor_points_;
    std::vector<cv::Point3f> large_armor_points_;
};

} // namespace PHOENIX::Math