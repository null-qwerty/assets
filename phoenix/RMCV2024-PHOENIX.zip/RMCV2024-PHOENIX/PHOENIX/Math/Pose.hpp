#pragma once

#ifdef USE_MKL
#define EIGEN_USE_MKL_ALL
#define EIGEN_VECTORIZE_AVX256
#endif

#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Geometry>

namespace PHOENIX::Math
{

class Pose {
public:
    Pose() = default;
    /**
   * @brief 从position和euler_angles构造Pose
   * @param position 位移，XYZ
   * @param euler_angles 欧拉角, RPY
   * @note 会从欧拉角构造四元数
   */
    Pose(const Eigen::Vector3d &position, const Eigen::Vector3d &euler_angles)
        : position_(position)
        , euler_angles_(euler_angles)
    {
        quaternion_ = Eigen::Quaterniond(
            Eigen::AngleAxisd(euler_angles_(0), Eigen::Vector3d::UnitX()) *
            Eigen::AngleAxisd(euler_angles_(1), Eigen::Vector3d::UnitY()) *
            Eigen::AngleAxisd(euler_angles_(2), Eigen::Vector3d::UnitZ()));
    }
    /**
   * @brief 从position和quaternion构造Pose
   * @param position 位移，XYZ
   * @param euler_angles 四元数
   * @note 会从四元数构造欧拉角
   */
    Pose(const Eigen::Vector3d &position, const Eigen::Quaterniond &quaternion)
        : position_(position)
        , quaternion_(quaternion)
    {
        euler_angles_ = quaternion_.toRotationMatrix().eulerAngles(0, 1, 2);
    }

    Eigen::Vector3d position_;
    Eigen::Vector3d euler_angles_;
    Eigen::Quaterniond quaternion_;

    /**
   * @brief 获取位移
   * @return Eigen::Vector3d position
   */
    Eigen::Vector3d getPosition() const
    {
        return position_;
    }
    /**
   * @brief 获取欧拉角
   * @return Eigen::Vector3d eular_angles
   */
    Eigen::Vector3d getEulerAngles() const
    {
        return euler_angles_;
    }
    /**
   * @brief 获取四元数
   * @return Eigen::Quaterniond quaternion
   */
    Eigen::Quaterniond getQuaternion() const
    {
        return quaternion_;
    }

    /**
   * @brief 设置位移
   * @param position 位移, XYZ
   */
    void setPosition(const Eigen::Vector3d &position)
    {
        position_ = position;
    }
    /**
   * @brief 设置欧拉角
   * @param eular_angles 欧拉角, RPY
   * @note 会从欧拉角构造四元数
   */
    void setEulerAngles(const Eigen::Vector3d &euler_angles)
    {
        euler_angles_ = euler_angles;
        quaternion_ = Eigen::Quaterniond(
            Eigen::AngleAxisd(euler_angles_(0), Eigen::Vector3d::UnitX()) *
            Eigen::AngleAxisd(euler_angles_(1), Eigen::Vector3d::UnitY()) *
            Eigen::AngleAxisd(euler_angles_(2), Eigen::Vector3d::UnitZ()));
    }
    /**
   * @brief 设置四元数
   * @param quaternion 四元数
   * @note 会从四元数构造欧拉角
   */
    void setQuaternion(const Eigen::Quaterniond &quaternion)
    {
        quaternion_ = quaternion;
        euler_angles_ = quaternion_.toRotationMatrix().eulerAngles(0, 1, 2);
    }
    /**
   * @brief 设置位移
   * @param x x方向
   * @param y y方向
   * @param z z方向
   */
    void setPosition(const double &x, const double &y, const double &z)
    {
        position_ << x, y, z;
        quaternion_ = Eigen::Quaterniond(
            Eigen::AngleAxisd(euler_angles_(0), Eigen::Vector3d::UnitX()) *
            Eigen::AngleAxisd(euler_angles_(1), Eigen::Vector3d::UnitY()) *
            Eigen::AngleAxisd(euler_angles_(2), Eigen::Vector3d::UnitZ()));
    }
    /**
   * @brief 设置欧拉角
   * @param roll 翻滚角, 绕x轴
   * @param pitch 俯仰角, 绕y轴
   * @param yaw 航向角, 绕z轴
   * @note 会从欧拉角构造四元数
   */
    void setEulerAngles(const double &roll, const double &pitch,
                        const double &yaw)
    {
        euler_angles_ << roll, pitch, yaw;
        quaternion_ = Eigen::Quaterniond(
            Eigen::AngleAxisd(euler_angles_(0), Eigen::Vector3d::UnitX()) *
            Eigen::AngleAxisd(euler_angles_(1), Eigen::Vector3d::UnitY()) *
            Eigen::AngleAxisd(euler_angles_(2), Eigen::Vector3d::UnitZ()));
    }
    /**
   * @brief 设置四元数
   * @param w 四元数w
   * @param x 四元数x
   * @param y 四元数y
   * @param z 四元数z
   * @note 会从四元数构造欧拉角
   */
    void setQuaternion(const double &w, const double &x, const double &y,
                       const double &z)
    {
        quaternion_ = Eigen::Quaterniond(w, x, y, z);
        euler_angles_ = quaternion_.toRotationMatrix().eulerAngles(0, 1, 2);
    }
};
} // namespace PHOENIX::Math