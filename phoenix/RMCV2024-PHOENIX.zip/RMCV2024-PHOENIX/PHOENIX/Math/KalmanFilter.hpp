#pragma once

#ifdef USE_MKL
#define EIGEN_USE_MKL_ALL
#define EIGEN_VECTORIZE_AVX256
#endif

#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/LU>
#include <eigen3/Eigen/QR>
#include <functional>

namespace PHOENIX::Math
{
class KalmanFilter_ {
public:
    using VecVecFunc = std::function<Eigen::VectorXd(const Eigen::VectorXd &)>;
    using VecMatFunc = std::function<Eigen::MatrixXd(const Eigen::VectorXd &)>;
    using VoidMatFunc = std::function<Eigen::MatrixXd()>;

    KalmanFilter_(VecVecFunc f, VecMatFunc m_f, VecVecFunc f_h, VecMatFunc m_h,
                  Eigen::MatrixXd Q, Eigen::MatrixXd R, Eigen::MatrixXd p0);
    KalmanFilter_(VecVecFunc f, VecMatFunc m_f, VecVecFunc f_h, VecMatFunc m_h,
                  Eigen::MatrixXd p0);

    virtual Eigen::MatrixXd Update(Eigen::VectorXd z) = 0;
    virtual Eigen::MatrixXd Predict() = 0;

protected:
    int Dim_; // 状态量维度

    // 状态量
    Eigen::VectorXd X_Crr_; // 当前值
    Eigen::VectorXd X_Pred_; // 预测值
    // 协方差
    Eigen::MatrixXd P_Crr_; // 当前值
    Eigen::MatrixXd P_Pred_; // 预测值

    VecVecFunc f_; // 状态转移函数
    VecMatFunc Matrix_f; // 状态转移函数的雅可比矩阵
    Eigen::MatrixXd F_; // 状态转移矩阵

    Eigen::MatrixXd B_; // 控制矩阵
    Eigen::VectorXd U_; // 控制量

    VecVecFunc h_; // 观测函数
    VecMatFunc Matrix_h; // 观测函数的雅可比矩阵
    Eigen::MatrixXd H_; // 观测矩阵

    // 误差
    Eigen::MatrixXd Q_; // 模型误差
    Eigen::MatrixXd R_; // 观测误差

    // 卡尔曼增益
    Eigen::MatrixXd K_;

    Eigen::MatrixXd I_; // 单位矩阵
};

class KalmanFilter : public KalmanFilter_ {
public:
    /**
     * @brief 卡尔曼滤波器构造函数
     * 
     * @param f 状态转移函数
     * @param m_f 状态转移函数的雅可比矩阵
     * @param f_h 观测函数
     * @param m_h 观测函数的雅可比矩阵
     * @param Q 模型误差
     * @param R 观测误差
     * @param p0 初始协方差
     */
    KalmanFilter(const VecVecFunc &f, const VecMatFunc &m_f,
                 const VecVecFunc &f_h, const VecMatFunc &m_h,
                 const Eigen::MatrixXd &Q, const Eigen::MatrixXd &R,
                 const Eigen::MatrixXd &p0);
    ~KalmanFilter() = default;
    
    /**
     * @brief 设置初始状态
     * 
     * @param x0 初始状态
     */
    void SetState(const Eigen::VectorXd &x0);

    /**
     * @brief 更新状态
     * 
     * @param z 观测值
     * @return Eigen::MatrixXd 更新后的状态 
     */
    Eigen::MatrixXd Update(Eigen::VectorXd z) override;

    /**
     * @brief 预测状态
     * 
     * @return Eigen::MatrixXd 预测状态
     */
    Eigen::MatrixXd Predict() override;

}; // class KalmanFilter

class ExtendedKalmanFilter : public KalmanFilter_ {
    using VoidMatFunc = std::function<Eigen::MatrixXd()>;

public:
    /**
     * @brief 扩展卡尔曼滤波器构造函数
     * 
     * @param f 状态转移函数
     * @param m_f 状态转移函数的雅可比矩阵
     * @param f_h 观测函数
     * @param m_h 观测函数的雅可比矩阵
     * @param u_Q 模型误差更新函数
     * @param u_R 观测误差更新函数
     * @param p0 初始协方差
     */
    ExtendedKalmanFilter(const VecVecFunc &f, const VecMatFunc &m_f,
                         const VecVecFunc &f_h, const VecMatFunc &m_h,
                         const VoidMatFunc &u_Q, const VecMatFunc &u_R,
                         const Eigen::MatrixXd &p0);
    ~ExtendedKalmanFilter() = default;

    /**
     * @brief 设置初始状态
     * 
     * @param x0 初始状态
     */
    void SetState(const Eigen::VectorXd &x0);

    /**
     * @brief 更新状态
     * 
     * @param z 观测值
     * @return Eigen::MatrixXd 更新后的状态 
     */
    Eigen::MatrixXd Update(Eigen::VectorXd z) override;

    /**
     * @brief 预测状态
     * 
     * @return Eigen::MatrixXd 预测状态
     */
    Eigen::MatrixXd Predict() override;

private:
    VoidMatFunc update_Q;
    VecMatFunc update_R;

}; // class ExtendedKalmanFilter

class UnscentedKalmanFilter : public KalmanFilter_ {
public:
    /**
     * @brief 无迹卡尔曼滤波器构造函数
     * 
     * @param f 状态转移函数
     * @param m_f 状态转移函数的雅可比矩阵
     * @param f_h 观测函数
     * @param m_h 观测函数的雅可比矩阵
     * @param Q 模型误差
     * @param R 观测误差
     * @param p0 初始协方差
     */
    UnscentedKalmanFilter(const VecVecFunc &f, const VecMatFunc &m_f,
                          const VecVecFunc &f_h, const VecMatFunc &m_h,
                          const Eigen::MatrixXd &Q, const Eigen::MatrixXd &R,
                          const Eigen::MatrixXd &p0);
    ~UnscentedKalmanFilter() = default;

    /**
     * @brief 设置初始状态
     * 
     * @param x0 初始状态
     */
    void SetState(const Eigen::VectorXd &x0);
    
    /**
     * @brief 更新状态
     * 
     * @param z 观测值
     * @return Eigen::MatrixXd 更新后的状态 
     */
    Eigen::MatrixXd Update(Eigen::VectorXd z) override;
    
    /**
     * @brief 预测状态
     * 
     * @return Eigen::MatrixXd 预测状态
     */
    Eigen::MatrixXd Predict() override;

private:
    Eigen::MatrixXd L_;
    Eigen::MatrixXd sigma_points_;
    Eigen::MatrixXd predicted_sigma_points_;
    Eigen::VectorXd y_;
    Eigen::MatrixXd mean_;
    Eigen::MatrixXd covariance_;

}; // class UnscentedKalmanFilter

} // namespace PHOENIX::Math