#pragma once

#ifdef USE_MKL
#define EIGEN_USE_MKL_ALL
#define EIGEN_VECTORIZE_AVX256
#endif

#include <eigen3/Eigen/Core>
#include <opencv2/core/cvdef.h>

#include "Utils/enum/bullet.hpp" //添加子弹类型枚举类

namespace PHOENIX::Math
{
/**
 * @brief
 * 用于将提前量(此处提前量的含义包含提前量原意和抬枪补偿)解算为云台转动角度的类
 * @author Exia
 */
class Lead {
public:
    Eigen::Vector3d shoot_pw; // 预瞄点的世界坐标
    Eigen::Vector3d d_shoot_pw; // 识别到的点增加抬枪补偿后的世界坐标
    Eigen::Vector3d shoot_pc;
    Eigen::Vector3d shoot_pu;
    Eigen::Vector3d orin_pw;
    Eigen::Vector3d orin_pc;
    Eigen::Vector3d orin_pu;

    /**
   * @brief
   * 构造函数设置现实环境的物理量，也可使用没有参数传入的构造函数，会有默认值设置
   * @param gravity 重力加速度常数
   * @param kofsmall 小弹丸风阻系数
   * @param koflarge 大弹丸风阻系数
   * @param koflight 荧光弹丸风阻系数
   * @param R_K_iter 龙格库塔法最大迭代次数
   * @param stop_error 停止迭代的最小误差(单位m)
   */
    Lead(const double &gravity, const double &kofsmall, const float &koflarge,
         const double &koflight, const double &R_K_iter,
         const double &stop_error);

    /**
   * @brief 使用默认值
   */
    Lead();

    ~Lead(){};

    /**
   * @brief 龙格库塔法求解微分方程，取得抬枪补偿(Ps:modify from TUP)
   * @param xyz 目标相对于云台的世界坐标系
   * @param velocity 子弹发射的速度
   * @param mode 子弹类型，有 Bullet::Small,Bullet::Larget,Bullet::Light
   */
    Eigen::Vector2d DynamicCalcCompensate(Eigen::Vector3d &xyz,
                                          const float &velocity,
                                          const Utils::Bullet &mode);

    /**
   *@brief 设置手动补偿量,px,py的物理含义为相机到摩擦轮出射处的偏移量
   */
    void SetHandOffSet(const double &x, const double &y);

private:
    double gravity; // 重力系数
    double kofsmall; // 小弹丸风阻系数
    double koflarge; // 大弹丸风阻系数
    double koflight; // 荧光弹丸风阻系数
    int max_iter; // 龙格库塔法最大迭代次数
    double velocity; // 弹丸速度
    int R_K_iter; // 龙格库塔法求解落点的迭代次数
    double stop_error; // 停止迭代的最小误差(单位m)
    double k; // 风阻系数
    double px; // yaw轴补偿
    double py; // pitch轴补偿
};
}; // namespace PHOENIX::Math