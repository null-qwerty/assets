#pragma once

#include <cmath>
#include <iostream>
#include <vector>

namespace PHOENIX::Math
{
class Quaternion {
public:
    Quaternion();
    /**
   * @brief 从四个分量构造四元数
   * @param x 四元数的x分量
   * @param y 四元数的y分量
   * @param z 四元数的z分量
   * @param w 四元数的w分量
   */
    Quaternion(double x, double y, double z, double w);
    Quaternion(const Quaternion &q);
    /**
   * @brief 从欧拉角构造四元数
   * @param yaw yaw角, 绕z轴旋转, 单位为弧度
   * @param pitch pitch角, 绕y轴旋转, 单位为弧度
   * @param roll roll角, 绕x轴旋转, 单位为弧度
   */
    Quaternion(double yaw, double pitch, double roll);
    ~Quaternion();

    Quaternion &operator=(const Quaternion &q);
    Quaternion operator*(const Quaternion &q) const;
    Quaternion &operator*=(const Quaternion &q);
    Quaternion operator*(double s) const;
    Quaternion &operator*=(double s);
    Quaternion operator+(const Quaternion &q) const;
    Quaternion &operator+=(const Quaternion &q);
    Quaternion operator-(const Quaternion &q) const;
    Quaternion &operator-=(const Quaternion &q);
    Quaternion operator/(double s) const;
    Quaternion &operator/=(double s);
    bool operator==(const Quaternion &q) const;
    bool operator!=(const Quaternion &q) const;

    /**
   * @brief 四元数长度
   * @return 四元数长度
   */
    double Length() const;
    /**
   * @brief 四元数长度的平方
   * @return 四元数长度的平方
   */
    double LengthSquared() const;
    /**
   * @brief 四元数归一化
   */
    void Normalize();
    /**
   * @brief 四元数归一化后的四元数
   * @return 四元数归一化后的四元数
   */
    Quaternion Normalized() const;
    /**
   * @brief 四元数共轭
   */
    void Conjugate();
    /**
   * @brief 四元数共轭后的四元数
   * @return 四元数共轭后的四元数
   */
    Quaternion Conjugated() const;
    /**
   * @brief 四元数求逆
   */
    void Invert();
    /**
   * @brief 四元数求逆后的四元数
   * @return 四元数求逆后的四元数
   */
    Quaternion Inverted() const;
    /**
   * @brief 四元数转欧拉角
   * @param yaw yaw角, 绕z轴旋转, 单位为弧度
   * @param pitch pitch角, 绕y轴旋转, 单位为弧度
   * @param roll roll角, 绕x轴旋转, 单位为弧度
   */
    void ToEuler(double &yaw, double &pitch, double &roll);

private:
    double x, y, z, w;
};

} // namespace PHOENIX::Math