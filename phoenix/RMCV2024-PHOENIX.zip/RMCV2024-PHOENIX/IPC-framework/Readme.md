# IPC-framework

一个在 UNIX/Linux 上的进程间通信框架

目前已有的后端： UNIX域套接字(UDS)、共享内存(SHM)

# 安装
```
sudo make install
```

# 卸载
```
sudo make uninstall
```

# 示例和文档
见 `doc` 目录下
