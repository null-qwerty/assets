# CVlib库

封装了一些常用的图形图像处理函数

## 二值化
```C++
/**
 * @brief 图像预处理
 * @param origin_frame 原始图像
 * @param result 二值化图像
 * @param detect_color 需要识别的颜色
 * @param morph 是否进行开运算
 * @param blur 是否进行高斯模糊
 */
void ImagePreprocessing(cv::Mat &origin_frame, cv::Mat &result,
                        PHOENIX::Utils::COLOR detect_color, bool morph = true, bool blur = true);
```

## 从外部文件读取相机内参
```C++
/**
 * @brief 获取相机内参
 * @param cameraMatrix 相机内参
 * @param distCoeffs 相机畸变参数
 * @param FilePath 相机内参文件路径
 */
void getCameraParm(cv::Mat &cameraMatrix, cv::Mat &distCoeffs,
                   std::string FilePath = "../config/camera.yml");
```