#include "CVlib/CVlib.hpp"

namespace PHOENIX::CVlib
{
void ImagePreprocessing(cv::Mat &origin_frame, cv::Mat &result,
                        PHOENIX::Utils::COLOR detect_color, int threshold,
                        int blue_threshold, int red_threshold, bool morph,
                        bool blur)
{
    static cv::Mat binary;
    static cv::Mat channals[3];

    cv::cvtColor(origin_frame, binary, cv::COLOR_BGR2GRAY);
    cv::threshold(binary, binary, threshold, 255, cv::THRESH_BINARY);

    cv::split(origin_frame, channals); // BGR
    cv::threshold(channals[0], channals[0], blue_threshold, 255,
                  cv::THRESH_BINARY);
    cv::threshold(channals[2], channals[2], red_threshold, 255,
                  cv::THRESH_BINARY);

    cv::Mat diff = (detect_color == PHOENIX::Utils::COLOR::RED ?
                        channals[2] - channals[0] :
                        channals[0] - channals[2]);
    cv::threshold(diff, diff, 0, 255, cv::THRESH_BINARY);

    cv::bitwise_and(binary, diff, result); // 按位与，提取出红色或蓝色

    if (morph)
        cv::morphologyEx(
            result, result, cv::MORPH_OPEN,
            cv::getStructuringElement(cv::MORPH_RECT,
                                      cv::Size(3, 3))); // 开运算，去除噪点
    if (blur)
        cv::GaussianBlur(result, result, cv::Size(3, 3),
                         5); // 高斯模糊，去除噪点
}

void getCameraParm(cv::Mat &cameraMatrix, cv::Mat &distCoeffs,
                   std::string FilePath)
{
    cv::FileStorage fs(FilePath, cv::FileStorage::READ);
    fs["camera_matrix"] >> cameraMatrix;
    fs["distortion_coefficients"] >> distCoeffs;
    fs.release();
}
} // namespace PHOENIX::cvlib
